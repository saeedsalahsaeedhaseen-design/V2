export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 بايت';
  if (isNaN(bytes) || bytes < 0) return '0 بايت';

  const k = 1024;
  const sizes = ['بايت', 'ك.ب', 'م.ب', 'ج.ب', 'ت.ب'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const idx = Math.min(i, sizes.length - 1);
  const val = bytes / Math.pow(k, idx);
  
  return `${val.toFixed(val >= 100 || idx === 0 ? 0 : 1)} ${sizes[idx]}`;
}

export function formatSpeed(bytesPerSecond: number): string {
  if (bytesPerSecond <= 0) return '0 م.ب/ث';
  const mbps = bytesPerSecond / (1024 * 1024);
  if (mbps >= 1) {
    return `${mbps.toFixed(1)} م.ب/ث`;
  }
  const kbps = bytesPerSecond / 1024;
  return `${kbps.toFixed(0)} ك.ب/ث`;
}

export function formatDuration(seconds: number): string {
  if (!seconds || seconds <= 0 || !isFinite(seconds)) return 'لحظات...';
  const sec = Math.ceil(seconds);
  if (sec < 60) {
    return `${sec} ثانية`;
  }
  const min = Math.floor(sec / 60);
  const remainingSec = sec % 60;
  if (min < 60) {
    return `${min} د و ${remainingSec} ث`;
  }
  const hours = Math.floor(min / 60);
  const remMin = min % 60;
  return `${hours} س و ${remMin} د`;
}

export type FileCategory = 'video' | 'image' | 'apk' | 'audio' | 'archive' | 'document' | 'other';

export function getFileCategory(filename: string, mimeType?: string): FileCategory {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  
  if (ext === 'apk' || mimeType?.includes('android.package-archive')) {
    return 'apk';
  }
  if (['mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'wmv'].includes(ext) || mimeType?.startsWith('video/')) {
    return 'video';
  }
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'heic'].includes(ext) || mimeType?.startsWith('image/')) {
    return 'image';
  }
  if (['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(ext) || mimeType?.startsWith('audio/')) {
    return 'audio';
  }
  if (['zip', 'rar', '7z', 'tar', 'gz', 'iso'].includes(ext)) {
    return 'archive';
  }
  if (['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'].includes(ext) || mimeType?.startsWith('text/')) {
    return 'document';
  }
  return 'other';
}

export function getCategoryLabel(category: FileCategory): string {
  switch (category) {
    case 'apk': return 'ألعاب وتطبيقات APK';
    case 'video': return 'فيديوهات';
    case 'image': return 'صور';
    case 'audio': return 'صوتيات';
    case 'archive': return 'ملفات مضغوطة';
    case 'document': return 'مستندات';
    default: return 'ملفات أخرى';
  }
}
