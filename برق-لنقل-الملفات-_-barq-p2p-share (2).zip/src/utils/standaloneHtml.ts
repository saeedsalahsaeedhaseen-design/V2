/**
 * Standalone, single-file index.html containing all HTML, CSS, JavaScript, and CDN scripts.
 * Upgraded with:
 * 1. Automatic 5GHz, 4G, and 3G Hotspot detection & dynamic chunking (256KB, 128KB, 32KB).
 * 2. Smart native CompressionStream ('gzip') on compressible files.
 * 3. Emergency Turbo Mode (CPU/RAM governor for weak or low-end receiver phones).
 */
export const STANDALONE_INDEX_HTML = `<!doctype html>
<html lang="ar" dir="rtl" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>بَـرْق لنقل الملفات | Barq P2P Turbo</title>
  <meta name="description" content="أسرع وأذكى نظام نقل بيانات محلي P2P عبر شبكات 5GHz و 4G و 3G مع ضغط ذكي ونظام Turbo لحماية الأجهزة الضعيفة" />
  <meta name="theme-color" content="#070B13" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: {
            sans: ['Readex Pro', 'system-ui', 'sans-serif'],
          },
        },
      },
    };
  </script>

  <!-- External CDN Libraries -->
  <script src="https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.4/build/qrcode.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.4/dist/confetti.browser.min.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    * { border-color: rgba(255, 255, 255, 0.08); }
    body {
      font-family: 'Readex Pro', system-ui, -apple-system, sans-serif;
      background-color: #070B13;
      color: #F1F5F9;
    }
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.6); }
    ::-webkit-scrollbar-thumb { background: rgba(148, 163, 184, 0.2); border-radius: 9999px; }
    .scan-beam {
      animation: scanAnimation 2s ease-in-out infinite alternate;
    }
    @keyframes scanAnimation {
      0% { top: 10%; opacity: 0.3; }
      50% { opacity: 1; }
      100% { top: 90%; opacity: 0.3; }
    }
  </style>
</head>
<body class="min-h-screen bg-[#070B13] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">

  <!-- Header -->
  <header class="sticky top-0 z-30 w-full bg-[#080C14]/90 backdrop-blur-md border-b border-white/8">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
      <!-- Zone 1: Wordmark -->
      <div class="flex items-center gap-2.5 shrink-0 cursor-pointer" onclick="resetToHome()">
        <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
          <i data-lucide="zap" class="w-5 h-5 text-white stroke-[2.5]"></i>
        </div>
        <div>
          <div class="flex items-center gap-1.5">
            <span class="text-lg font-bold tracking-tight text-white">بَـرْق</span>
            <span class="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">Turbo P2P</span>
          </div>
          <p class="text-[10px] text-slate-400 -mt-0.5">نقل ذكي فائق السرعة عبر 5GHz / 4G / 3G</p>
        </div>
      </div>

      <!-- Zone 2: Navigation Info -->
      <nav class="hidden md:flex items-center gap-6 text-xs text-slate-300">
        <div class="flex items-center gap-1.5">
          <i data-lucide="wifi" class="w-3.5 h-3.5 text-emerald-400"></i>
          <span>توافق 5GHz و 4G و 3G</span>
        </div>
        <span class="text-white/20">·</span>
        <span>ضغط ذكي للبيانات</span>
        <span class="text-white/20">·</span>
        <span>نظام Turbo لحماية المعالج</span>
      </nav>

      <!-- Zone 3: Actions -->
      <div class="flex items-center gap-2">
        <button
          onclick="downloadSelfHtml()"
          class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 rounded-lg shadow-md shadow-emerald-500/20 transition-all active:scale-95 whitespace-nowrap"
          title="تنزيل كود ملف index.html بالكامل إلى جوالك"
        >
          <i data-lucide="download" class="w-3.5 h-3.5"></i>
          <span>تنزيل ملف index.html</span>
        </button>

        <button
          onclick="openSimulatorModal()"
          class="hidden sm:inline-flex px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 rounded-lg border border-white/5 transition-colors whitespace-nowrap"
        >
          محاكي السرعة
        </button>
        
        <button
          onclick="openHotspotModal()"
          class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-lg transition-all active:scale-95 whitespace-nowrap"
        >
          <i data-lucide="help-circle" class="w-3.5 h-3.5"></i>
          <span>دليل الشبكات</span>
        </button>
      </div>
    </div>
  </header>

  <!-- Main Container -->
  <main class="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5">
    <!-- Notice & Controls Banner -->
    <div class="space-y-3">
      <div class="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-teal-950/40 border border-emerald-500/20 p-4 sm:p-4.5 text-slate-200 shadow-xl shadow-emerald-950/20">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
          <div class="flex items-center gap-3.5">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0 text-emerald-400">
              <i data-lucide="radio" class="w-5 h-5 animate-pulse"></i>
            </div>
            <div class="space-y-0.5">
              <div class="flex flex-wrap items-center gap-2">
                <span class="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                  توافق ذكي مع 5GHz و 4G و 3G Hotspot
                </span>
                <span class="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                  تجزئة ديناميكية + ضغط ذكي
                </span>
              </div>
              <p class="text-sm font-medium text-slate-100 leading-relaxed">
                يتعرف التطبيق تلقائياً على قوة الشبكة (5GHz أو 4G أو 3G) ويضبط حجم الحزم ويضغط البيانات تلقائياً، مع وضع <strong>Turbo</strong> لحماية الأجهزة الضعيفة من التهنيج.
              </p>
            </div>
          </div>

          <button
            onclick="openHotspotModal()"
            class="self-end sm:self-center shrink-0 flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:text-emerald-200 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl transition-all active:scale-95"
          >
            <span>دليل الشبكات</span>
            <i data-lucide="chevron-left" class="w-4 h-4"></i>
          </button>
        </div>
      </div>

      <!-- Network Mode & Turbo Mode Switches -->
      <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/70 border border-white/8 text-xs">
        <div class="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <span class="text-slate-400 shrink-0 font-medium flex items-center gap-1">
            <i data-lucide="wifi" class="w-3.5 h-3.5 text-emerald-400"></i>
            <span>نمط الشبكة:</span>
          </span>
          <div class="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-white/5 shrink-0">
            <button id="btnTierAuto" onclick="setNetworkTier('auto')" class="px-2.5 py-1 rounded-lg font-bold bg-emerald-500 text-slate-950">تلقائي (Auto)</button>
            <button id="btnTier5G" onclick="setNetworkTier('5ghz')" class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white">5GHz (256KB)</button>
            <button id="btnTier4G" onclick="setNetworkTier('4g')" class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white">4G (128KB)</button>
            <button id="btnTier3G" onclick="setNetworkTier('3g')" class="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white">3G (32KB)</button>
          </div>
        </div>

        <div class="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0">
          <div class="flex items-center gap-1.5">
            <i data-lucide="cpu" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i>
            <span class="font-bold text-white">وضع التوربو للطوارئ</span>
            <span class="text-[10px] text-slate-400 hidden md:inline">(توفير المعالج)</span>
          </div>
          <button
            id="turboSwitchBtn"
            onclick="toggleTurboMode()"
            class="relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 bg-amber-500"
          >
            <span id="turboSwitchKnob" class="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 -translate-x-5"></span>
          </button>
        </div>
      </div>
    </div>

    <!-- Global Error Banner -->
    <div id="errorBanner" class="hidden p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-200 text-xs flex items-center justify-between gap-3">
      <div class="flex items-center gap-2">
        <i data-lucide="alert-circle" class="w-4 h-4 text-rose-400 shrink-0"></i>
        <span id="errorMessage"></span>
      </div>
      <button onclick="hideError()" class="text-slate-400 hover:text-white text-xs font-semibold">إغلاق</button>
    </div>

    <!-- VIEW 1: HOME (Dual Cards) -->
    <div id="viewHome" class="space-y-6">
      <div class="text-center space-y-2 py-4">
        <h1 class="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          نظام النقل المباشر الذكي فائق السرعة
        </h1>
        <p class="text-sm text-slate-400 max-w-lg mx-auto leading-relaxed">
          انقل الفيديوهات الضخمة، وألعاب وتطبيقات <span class="text-emerald-400 font-semibold">APK</span>، والصور بأقصى سرعة اتصال محلي P2P عبر شبكات 5GHz و 4G و 3G مع ضغط ذكي فوري.
        </p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
        <!-- Option 1: Send Files -->
        <div 
          onclick="startSenderMode()"
          class="group relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-white/10 hover:border-emerald-500/50 p-6 sm:p-8 transition-all hover:shadow-2xl hover:shadow-emerald-500/10 active:scale-[0.99] flex flex-col justify-between space-y-6"
        >
          <div class="space-y-4">
            <div class="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform shadow-lg shadow-emerald-500/10">
              <i data-lucide="send" class="w-7 h-7 -translate-x-0.5"></i>
            </div>
            <div class="space-y-2">
              <div class="flex items-center gap-2">
                <h3 class="text-xl sm:text-2xl font-bold text-white group-hover:text-emerald-300 transition-colors">إرسال ملفات</h3>
                <span class="text-xs bg-emerald-500/20 text-emerald-400 font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">المرسل</span>
              </div>
              <p class="text-xs sm:text-sm text-slate-400 leading-relaxed">
                اختر ملفاتك بأي حجم، مع ميزة التجزئة المتكيفة والضغط الذكي وتوليد كود اتصال ورمز QR فوري.
              </p>
            </div>
          </div>
          <div class="pt-4 border-t border-white/5 flex items-center justify-between">
            <span class="text-xs text-emerald-400 font-semibold group-hover:underline">بدء الإرسال وتوليد الرمز</span>
            <div class="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-all">
              <i data-lucide="arrow-left" class="w-4 h-4"></i>
            </div>
          </div>
        </div>

        <!-- Option 2: Receive Files -->
        <div 
          onclick="startReceiverMode()"
          class="group relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-white/10 hover:border-cyan-500/50 p-6 sm:p-8 transition-all hover:shadow-2xl hover:shadow-cyan-500/10 active:scale-[0.99] flex flex-col justify-between space-y-6"
        >
          <div class="space-y-4">
            <div class="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform shadow-lg shadow-cyan-500/10">
              <i data-lucide="download" class="w-7 h-7"></i>
            </div>
            <div class="space-y-2">
              <div class="flex items-center gap-2">
                <h3 class="text-xl sm:text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">استلام ملفات</h3>
                <span class="text-xs bg-cyan-500/20 text-cyan-400 font-mono px-2 py-0.5 rounded-full border border-cyan-500/30">المستلم</span>
              </div>
              <p class="text-xs sm:text-sm text-slate-400 leading-relaxed">
                امسح رمز QR الخاص بالجوال المرسل، واستقبل الملفات مع حماية نظام Turbo من التهنيج وتجميع الذاكرة.
              </p>
            </div>
          </div>
          <div class="pt-4 border-t border-white/5 flex items-center justify-between">
            <span class="text-xs text-cyan-400 font-semibold group-hover:underline">مسح الكود أو الإدخال اليدوي</span>
            <div class="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all">
              <i data-lucide="arrow-left" class="w-4 h-4"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- VIEW 2: SENDER MODE -->
    <div id="viewSender" class="hidden space-y-6">
      <div class="flex items-center justify-between pb-2 border-b border-white/5">
        <div class="flex items-center gap-2">
          <button onclick="resetToHome()" class="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white">
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </button>
          <h2 class="text-lg font-bold text-white">إرسال ملفات (الجوال المرسل)</h2>
        </div>
        <button onclick="resetToHome()" class="text-xs text-slate-400 hover:text-white">رجوع للرئيسية</button>
      </div>

      <div class="rounded-3xl bg-slate-900/50 border border-white/10 p-5 sm:p-6 space-y-5">
        <div id="senderConnStatus" class="p-3 rounded-xl border bg-slate-800/60 border-white/5 text-slate-300 flex items-center justify-between gap-3">
          <div class="flex items-center gap-2.5">
            <i data-lucide="radio" class="w-4 h-4 text-amber-400 animate-pulse"></i>
            <span id="senderConnText" class="text-xs sm:text-sm font-medium">بانتظار مسح الرمز من الجوال المستلم...</span>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center">
          <div class="flex flex-col items-center justify-center p-4 bg-white rounded-2xl shadow-xl shadow-black/40">
            <canvas id="qrCanvas" class="rounded-lg max-w-[180px] h-auto"></canvas>
            <p class="text-[11px] font-semibold text-slate-800 mt-2 flex items-center gap-1.5">
              <i data-lucide="smartphone" class="w-3.5 h-3.5 text-emerald-600"></i>
              <span>امسح الرمز بكاميرا الجوال المستلم</span>
            </p>
          </div>

          <div class="space-y-4 text-center sm:text-right">
            <div>
              <span class="text-xs text-slate-400 font-medium">كود الاتصال السريع:</span>
              <div class="mt-1 flex items-center justify-center sm:justify-start gap-2">
                <span id="senderShortCode" class="text-2xl sm:text-3xl font-mono font-bold tracking-widest text-emerald-400 bg-emerald-500/10 px-3.5 py-1.5 rounded-xl border border-emerald-500/25">--- ---</span>
                <button onclick="copyCode()" class="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-white/5">
                  <i data-lucide="copy" class="w-5 h-5"></i>
                </button>
              </div>
            </div>
            <p class="text-[11px] text-slate-400 leading-relaxed">
              يدعم الاتصال عبر نقاط اتصال 5GHz و 4G و 3G بدون إنترنت مع تجزئة ذكية تلقائية.
            </p>
          </div>
        </div>
      </div>

      <div class="space-y-4">
        <input id="fileInput" type="file" multiple class="hidden" onchange="handleFilesSelected(event)" />
        <div onclick="document.getElementById('fileInput').click()" class="border-2 border-dashed border-white/12 hover:border-emerald-500/40 rounded-3xl p-6 sm:p-8 text-center cursor-pointer bg-slate-900/40 hover:bg-slate-900/70 transition-all">
          <div class="flex flex-col items-center justify-center gap-3">
            <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <i data-lucide="upload-cloud" class="w-7 h-7"></i>
            </div>
            <h4 class="text-base sm:text-lg font-bold text-white">اضغط لاختيار الملفات أو اسحبها هنا</h4>
            <p class="text-xs text-slate-400">يدعم ألعاب وتطبيقات APK، وفيديوهات 4K، والمستندات مع ضغط تلقائي للملفات القابلة للضغط</p>
          </div>
        </div>

        <div class="flex items-center justify-between text-xs">
          <button onclick="addDemoSampleFiles()" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/25">
            <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
            <span>إضافة عينة ملفات ضخمة (APK + فيديو 4K)</span>
          </button>
          <button onclick="clearFiles()" class="text-rose-400 hover:text-rose-300">تفريغ القائمة</button>
        </div>

        <div id="fileListContainer" class="space-y-2 max-h-60 overflow-y-auto"></div>

        <button id="btnSendFiles" onclick="startSendingFiles()" disabled class="w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-3 bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5 transition-all">
          <i data-lucide="send" class="w-5 h-5 -translate-x-0.5"></i>
          <span id="btnSendFilesText">اختر الملفات أولاً لبدء النقل</span>
        </button>
      </div>
    </div>

    <!-- VIEW 3: RECEIVER MODE -->
    <div id="viewReceiver" class="hidden space-y-6">
      <div class="flex items-center justify-between pb-2 border-b border-white/5">
        <div class="flex items-center gap-2">
          <button onclick="resetToHome()" class="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white">
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </button>
          <h2 class="text-lg font-bold text-white">استلام ملفات (الجوال المستلم)</h2>
        </div>
        <button onclick="resetToHome()" class="text-xs text-slate-400 hover:text-white">رجوع للرئيسية</button>
      </div>

      <div class="rounded-3xl bg-slate-900/50 border border-white/10 p-6 sm:p-8 space-y-6">
        <div class="text-center space-y-4">
          <button onclick="openScannerModal()" class="w-full sm:w-auto mx-auto py-4 px-8 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold text-base flex items-center justify-center gap-3 shadow-xl shadow-emerald-500/20 active:scale-95 transition-all">
            <i data-lucide="camera" class="w-6 h-6"></i>
            <span>مسح رمز QR من الجوال المرسل</span>
          </button>
          <p class="text-xs text-slate-400">سيفتح الكاميرا لمسح الرمز المعروض على شاشة الجوال الآخر للربط التلقائي</p>
        </div>

        <div class="relative flex items-center justify-center">
          <div class="border-t border-white/10 w-full"></div>
          <span class="bg-[#0C121F] px-4 text-xs text-slate-400 font-medium">أو إدخال الكود يدوياً</span>
        </div>

        <div class="max-w-md mx-auto space-y-3">
          <label class="text-xs font-semibold text-slate-300 block text-right">كود الاتصال السريع (6 أرقام):</label>
          <div class="flex items-center gap-2">
            <input id="receiverCodeInput" type="text" placeholder="مثال: 942-815" class="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-white/10 text-white font-mono text-center text-lg sm:text-xl tracking-widest focus:outline-none focus:border-emerald-500" />
            <button onclick="connectByManualCode()" class="py-3 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm transition-colors border border-white/10 shrink-0">اتصال فوري</button>
          </div>
        </div>

        <div id="receiverConnStatus" class="p-4 rounded-xl border bg-slate-950/60 border-white/5 text-slate-400 flex items-center justify-center gap-2.5 text-xs font-medium">
          <i data-lucide="wifi" class="w-4 h-4"></i>
          <span id="receiverConnText">بانتظار مسح الرمز أو إدخال الكود للربط المباشر...</span>
        </div>
      </div>
    </div>

    <!-- VIEW 4: LIVE TRANSFER PROGRESS VIEW -->
    <div id="viewTransfer" class="hidden space-y-6">
      <div class="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#0F172A] to-[#0A0F1D] border border-white/10 p-6 shadow-2xl">
        <div class="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div class="flex items-center gap-5">
            <div class="relative w-24 h-24 rounded-full bg-slate-900 border-2 border-emerald-500/30 flex flex-col items-center justify-center shadow-lg shadow-emerald-500/10">
              <i data-lucide="zap" class="w-6 h-6 text-emerald-400"></i>
              <span class="text-xs font-semibold text-slate-400 mt-1">السرعة الحالية</span>
            </div>
            <div class="space-y-1.5 text-right">
              <div class="flex items-baseline gap-2">
                <span id="speedVal" class="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight text-white tabular-nums">0 م.ب/ث</span>
                <span class="text-xs font-semibold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/20">مباشر P2P</span>
              </div>
              
              <!-- Badges -->
              <div class="flex flex-wrap items-center gap-1.5 text-[11px]">
                <span id="badgeNetworkTier" class="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-medium">5GHz / 4G</span>
                <span id="badgeChunkSize" class="px-2 py-0.5 rounded-md bg-slate-800 text-cyan-300 font-mono">حزم 256KB ديناميكية</span>
                <span id="badgeTurbo" class="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-semibold">وضع Turbo (حماية المعالج)</span>
              </div>

              <p class="text-xs text-slate-400 flex items-center gap-1.5 pt-0.5">
                <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                <span>الوقت المتبقي: </span>
                <strong id="timeRemainingVal" class="text-slate-200">لحظات...</strong>
              </p>
            </div>
          </div>

          <div class="w-full md:w-auto flex md:flex-col items-center md:items-end justify-between gap-3 border-t md:border-t-0 border-white/5 pt-4 md:pt-0 text-right">
            <div>
              <span class="text-xs text-slate-400">إجمالي المنقول</span>
              <p id="totalTransferredVal" class="text-lg font-bold font-mono text-slate-100 tabular-nums">0 بايت من 0 بايت</p>
            </div>
            <div id="compressionSavedTag" class="bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-xl">
              <span class="text-[10px] text-emerald-400 block font-medium">وفّر الضغط الذكي:</span>
              <span id="compressionSavedVal" class="text-xs font-bold text-emerald-300 font-mono">+0 م.ب</span>
            </div>
            <div>
              <span class="text-xs text-slate-400">الملفات المنجزة</span>
              <p id="filesCompletedVal" class="text-sm font-semibold text-emerald-400">0 من 0 ملف</p>
            </div>
          </div>
        </div>

        <div class="mt-6 space-y-2">
          <div class="flex justify-between items-center text-xs font-semibold">
            <span id="transferStatusHeadline" class="text-slate-300">جاري النقل بتجزئة ذكية متكيفة مع الشبكة...</span>
            <span id="masterPercent" class="text-emerald-400 font-mono text-sm tabular-nums">0.0%</span>
          </div>
          <div class="h-3.5 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div id="masterProgressBar" class="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 rounded-full transition-all duration-300" style="width: 0%"></div>
          </div>
        </div>
      </div>

      <div id="completionBanner" class="hidden p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <i data-lucide="check-circle" class="w-5 h-5"></i>
          </div>
          <div>
            <h4 class="text-base font-bold text-white">تم نقل جميع الملفات بنجاح! 🚀</h4>
            <p class="text-xs text-slate-300">تم استلام وتجميع كافة الملفات بأمان تام وبدون أي انقطاع.</p>
          </div>
        </div>
        <div class="flex items-center gap-2.5">
          <button id="btnDownloadAll" onclick="downloadAllFiles()" class="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg transition-all">تحميل كافة الملفات</button>
          <button onclick="resetToHome()" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs">نقل جديد</button>
        </div>
      </div>

      <div class="space-y-3">
        <div class="flex items-center justify-between text-sm">
          <h4 class="font-bold text-white flex items-center gap-2">
            <i data-lucide="hard-drive" class="w-4 h-4 text-emerald-400"></i>
            <span>تفاصيل الملفات المنقولة</span>
          </h4>
          <button onclick="cancelTransfer()" class="text-xs text-rose-400 hover:text-rose-300">إلغاء النقل</button>
        </div>
        <div id="transferFilesList" class="space-y-2.5"></div>
      </div>
    </div>
  </main>

  <!-- Modals -->
  <!-- Guide Modal -->
  <div id="modalHotspot" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
    <div class="w-full max-w-xl bg-[#0E1524] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
      <div class="px-6 py-5 border-b border-white/8 flex items-center justify-between">
        <h3 class="text-lg font-bold text-white flex items-center gap-2">
          <i data-lucide="wifi" class="w-5 h-5 text-emerald-400"></i>
          <span>دليل شبكات 5GHz و 4G ونظام Turbo</span>
        </h3>
        <button onclick="closeHotspotModal()" class="w-8 h-8 rounded-lg bg-white/5 text-slate-400 hover:text-white flex items-center justify-center">✕</button>
      </div>
      <div class="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-300">
        <div class="p-4 rounded-xl bg-slate-900/60 border border-emerald-500/20 space-y-1">
          <strong class="text-emerald-300 block text-sm">1. نقطة اتصال 5GHz:</strong>
          <p class="text-slate-400">حزم ضخمة 256KB لأقصى سرعة نقل (حتى 100 ميجابايت/ث) للألعاب والفيديوهات.</p>
        </div>
        <div class="p-4 rounded-xl bg-slate-900/60 border border-sky-500/20 space-y-1">
          <strong class="text-sky-300 block text-sm">2. نقطة اتصال 4G / واي فاي 2.4GHz:</strong>
          <p class="text-slate-400">حزم 128KB متوازنة تضمن استقرار النقل عبر المسافات والأجهزة المتنوعة.</p>
        </div>
        <div class="p-4 rounded-xl bg-slate-900/60 border border-amber-500/20 space-y-1">
          <strong class="text-amber-300 block text-sm">3. نقطة اتصال 3G / شبكة ضعيفة:</strong>
          <p class="text-slate-400">حزم 32KB خفيفة تمنع انقطاع النقل أو سقوط الاتصال على الهواتف القديمة.</p>
        </div>
        <div class="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1">
          <strong class="text-amber-400 block text-sm">⚡ نظام Turbo Mode:</strong>
          <p class="text-slate-400">يقوم بتجميع البيانات في كتل 16MB وتقليل تحديثات الشاشة لتوفير 70% من طاقة المعالج والذاكرة وحماية الجوال المستقبل من التهنيج.</p>
        </div>
      </div>
      <div class="px-6 py-4 border-t border-white/8 bg-slate-950/40 flex justify-end">
        <button onclick="closeHotspotModal()" class="px-5 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold">إغلاق</button>
      </div>
    </div>
  </div>

  <!-- QR Scanner Modal -->
  <div id="modalScanner" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
    <div class="w-full max-w-md bg-[#0C121F] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
      <div class="p-4 px-6 border-b border-white/8 flex items-center justify-between">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i data-lucide="camera" class="w-4 h-4 text-emerald-400"></i>
          <span>مسح رمز QR للجوال المرسل</span>
        </h3>
        <button onclick="closeScannerModal()" class="w-8 h-8 rounded-lg bg-white/5 text-slate-400 hover:text-white flex items-center justify-center">✕</button>
      </div>
      <div class="relative aspect-square w-full bg-black overflow-hidden flex items-center justify-center">
        <video id="scannerVideo" class="w-full h-full object-cover" autoplay playsinline muted></video>
        <canvas id="scannerCanvas" class="hidden"></canvas>
        <div class="absolute inset-0 pointer-events-none flex items-center justify-center p-12">
          <div class="relative w-full h-full border-2 border-emerald-400 rounded-2xl shadow-[0_0_0_9999px_rgba(0,0,0,0.6)]">
            <div class="absolute left-2 right-2 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent scan-beam"></div>
          </div>
        </div>
      </div>
      <div class="p-4 bg-slate-900/60 border-t border-white/8 flex items-center justify-between">
        <input id="qrImageFileInput" type="file" accept="image/*" class="hidden" onchange="handleQrScreenshot(event)" />
        <button onclick="document.getElementById('qrImageFileInput').click()" class="text-xs text-emerald-400 hover:underline">
          مسح من لقطة شاشة
        </button>
        <span class="text-xs text-slate-500">أو وجّه الكاميرا للرمز</span>
      </div>
    </div>
  </div>

  <!-- Benchmark Simulator Modal -->
  <div id="modalSimulator" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
    <div class="w-full max-w-md bg-[#0C121F] border border-white/10 rounded-3xl overflow-hidden shadow-2xl p-6 space-y-4">
      <h3 class="text-base font-bold text-white flex items-center gap-2">
        <i data-lucide="zap" class="w-5 h-5 text-emerald-400"></i>
        <span>محاكي السرعة والشبكات (Benchmark)</span>
      </h3>
      <p class="text-xs text-slate-400">اختر نوع الشبكة لاختبار التجزئة الديناميكية ومعدل السرعة ونظام Turbo محلياً:</p>
      
      <div class="grid grid-cols-3 gap-2 text-xs">
        <button id="simBtn5G" onclick="setSimTier('5ghz')" class="p-2.5 rounded-xl border border-emerald-500 bg-emerald-500/15 text-white font-bold text-center">
          <div>5GHz</div>
          <div class="text-[10px] text-emerald-400 mt-0.5">256KB (~75MB/s)</div>
        </button>
        <button id="simBtn4G" onclick="setSimTier('4g')" class="p-2.5 rounded-xl border border-white/5 bg-slate-900/50 text-slate-400 text-center">
          <div>4G</div>
          <div class="text-[10px] text-sky-400 mt-0.5">128KB (~28MB/s)</div>
        </button>
        <button id="simBtn3G" onclick="setSimTier('3g')" class="p-2.5 rounded-xl border border-white/5 bg-slate-900/50 text-slate-400 text-center">
          <div>3G</div>
          <div class="text-[10px] text-amber-400 mt-0.5">32KB (~8.5MB/s)</div>
        </button>
      </div>

      <div class="pt-2 flex justify-end gap-2">
        <button onclick="closeSimulatorModal()" class="px-4 py-2 rounded-xl text-slate-400 text-xs">إلغاء</button>
        <button onclick="runLocalBenchmark()" class="px-5 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20">بدء المحاكاة الآن</button>
      </div>
    </div>
  </div>

  <!-- JavaScript Application Logic -->
  <script>
    // State
    let currentRole = 'idle';
    let peerInstance = null;
    let dataConn = null;
    let localShortCode = '';
    let selectedFiles = [];
    let transferFilesState = [];
    let isTransferring = false;
    let scannerStream = null;
    let scannerAnimFrame = null;
    let speedInterval = null;
    let speedHistory = [];

    // Adaptive Networks and Turbo Mode
    let networkTier = 'auto'; // 'auto', '5ghz', '4g', '3g'
    let turboMode = true; // Turbo mode enabled by default
    let simSelectedTier = '5ghz';
    let compressionSavingsTotal = 0;

    // Receiver batch memory segments for Turbo Mode
    let receiverSegments = new Map();
    let receiverBuffer = new Map();

    function getChunkSize() {
      if (networkTier === '5ghz') return 256 * 1024;
      if (networkTier === '4g') return 128 * 1024;
      if (networkTier === '3g') return 32 * 1024;
      // Auto
      const navConn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
      if (navConn && navConn.downlink && navConn.downlink >= 30) return 256 * 1024;
      if (navConn && (navConn.effectiveType === '3g' || (navConn.downlink && navConn.downlink < 10))) return 32 * 1024;
      return 128 * 1024;
    }

    function setNetworkTier(tier) {
      networkTier = tier;
      ['btnTierAuto', 'btnTier5G', 'btnTier4G', 'btnTier3G'].forEach(id => {
        const el = document.getElementById(id);
        el.className = 'px-2.5 py-1 rounded-lg text-slate-400 hover:text-white';
      });
      const activeBtn = tier === 'auto' ? 'btnTierAuto' : tier === '5ghz' ? 'btnTier5G' : tier === '4g' ? 'btnTier4G' : 'btnTier3G';
      document.getElementById(activeBtn).className = 'px-2.5 py-1 rounded-lg font-bold bg-emerald-500 text-slate-950';
    }

    function toggleTurboMode() {
      turboMode = !turboMode;
      const btn = document.getElementById('turboSwitchBtn');
      const knob = document.getElementById('turboSwitchKnob');
      if (turboMode) {
        btn.className = 'relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 bg-amber-500';
        knob.className = 'pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 -translate-x-5';
      } else {
        btn.className = 'relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 bg-slate-800';
        knob.className = 'pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 translate-x-0';
      }
    }

    function setSimTier(tier) {
      simSelectedTier = tier;
      ['simBtn5G', 'simBtn4G', 'simBtn3G'].forEach(id => {
        const el = document.getElementById(id);
        el.className = 'p-2.5 rounded-xl border border-white/5 bg-slate-900/50 text-slate-400 text-center';
      });
      const target = tier === '5ghz' ? 'simBtn5G' : tier === '4g' ? 'simBtn4G' : 'simBtn3G';
      document.getElementById(target).className = 'p-2.5 rounded-xl border border-emerald-500 bg-emerald-500/15 text-white font-bold text-center';
    }

    function initIcons() {
      if (window.lucide) {
        lucide.createIcons();
      }
    }

    window.addEventListener('DOMContentLoaded', () => {
      initIcons();
      const params = new URLSearchParams(window.location.search);
      const connParam = params.get('connect');
      if (connParam) {
        startReceiverMode();
        document.getElementById('receiverCodeInput').value = connParam;
        connectByManualCode();
      }
    });

    function showError(msg) {
      document.getElementById('errorMessage').textContent = msg;
      document.getElementById('errorBanner').classList.remove('hidden');
    }
    function hideError() {
      document.getElementById('errorBanner').classList.add('hidden');
    }

    function formatBytes(bytes) {
      if (!bytes || bytes <= 0) return '0 بايت';
      const k = 1024;
      const sizes = ['بايت', 'ك.ب', 'م.ب', 'ج.ب'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      const idx = Math.min(i, sizes.length - 1);
      return (bytes / Math.pow(k, idx)).toFixed(idx === 0 ? 0 : 1) + ' ' + sizes[idx];
    }

    function resetToHome() {
      if (peerInstance) {
        try { peerInstance.destroy(); } catch (e) {}
        peerInstance = null;
      }
      if (scannerStream) {
        scannerStream.getTracks().forEach(t => t.stop());
        scannerStream = null;
      }
      if (speedInterval) clearInterval(speedInterval);

      currentRole = 'idle';
      selectedFiles = [];
      transferFilesState = [];
      isTransferring = false;
      receiverSegments.clear();
      receiverBuffer.clear();
      hideError();

      document.getElementById('viewHome').classList.remove('hidden');
      document.getElementById('viewSender').classList.add('hidden');
      document.getElementById('viewReceiver').classList.add('hidden');
      document.getElementById('viewTransfer').classList.add('hidden');
      document.getElementById('completionBanner').classList.add('hidden');
    }

    // Sender Flow
    function startSenderMode() {
      currentRole = 'sender';
      document.getElementById('viewHome').classList.add('hidden');
      document.getElementById('viewSender').classList.remove('hidden');
      initIcons();

      const digits = Math.floor(100000 + Math.random() * 900000).toString();
      const codeFormatted = digits.slice(0, 3) + '-' + digits.slice(3);
      localShortCode = codeFormatted;
      document.getElementById('senderShortCode').textContent = codeFormatted;

      const fullPeerId = 'barq-' + digits;
      peerInstance = new Peer(fullPeerId, {
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
          ]
        }
      });

      const shareUrl = window.location.origin + window.location.pathname + '?connect=' + digits;
      const canvas = document.getElementById('qrCanvas');
      if (window.QRCode) {
        QRCode.toCanvas(canvas, shareUrl, { width: 180, margin: 1 });
      }

      peerInstance.on('connection', (conn) => {
        dataConn = conn;
        setupDataConnection();
      });

      peerInstance.on('error', (err) => {
        showError('تعذر الاتصال بخادم التنسيق P2P، تحقق من الشبكة.');
      });
    }

    // Receiver Flow
    function startReceiverMode() {
      currentRole = 'receiver';
      document.getElementById('viewHome').classList.add('hidden');
      document.getElementById('viewReceiver').classList.remove('hidden');
      initIcons();

      peerInstance = new Peer({
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
          ]
        }
      });
    }

    function connectByManualCode() {
      const val = document.getElementById('receiverCodeInput').value.trim().replace(/[^a-zA-Z0-9]/g, '');
      if (!val) {
        showError('يرجى إدخال كود الاتصال');
        return;
      }
      const remotePeerId = val.startsWith('barq') ? val : 'barq-' + val;
      document.getElementById('receiverConnText').textContent = 'جاري الاتصال بالجوال المرسل...';

      if (!peerInstance || peerInstance.destroyed) {
        peerInstance = new Peer();
        peerInstance.on('open', () => {
          doConnect(remotePeerId);
        });
      } else {
        doConnect(remotePeerId);
      }
    }

    function doConnect(targetId) {
      dataConn = peerInstance.connect(targetId, { reliable: true, serialization: 'binary' });
      setupDataConnection();
    }

    function setupDataConnection() {
      dataConn.on('open', () => {
        if (currentRole === 'sender') {
          document.getElementById('senderConnText').textContent = 'تم الاتصال بالجوال المستلم بنجاح! ⚡';
          document.getElementById('senderConnStatus').classList.remove('bg-slate-800/60');
          document.getElementById('senderConnStatus').classList.add('bg-emerald-500/15', 'border-emerald-500/30', 'text-emerald-300');
          updateSendButtonState();
        } else {
          document.getElementById('receiverConnText').textContent = 'متصل الآن بالجوال المرسل! بانتظار إرسال الملفات...';
          document.getElementById('receiverConnStatus').classList.add('bg-emerald-500/15', 'border-emerald-500/30', 'text-emerald-300');
        }
      });

      dataConn.on('data', (packet) => {
        handleIncomingPacket(packet);
      });
    }

    function handleFilesSelected(e) {
      if (e.target.files && e.target.files.length > 0) {
        selectedFiles = [...selectedFiles, ...Array.from(e.target.files)];
        renderSelectedFiles();
        updateSendButtonState();
      }
    }

    function addDemoSampleFiles() {
      const dummyBuffer = new Uint8Array(64 * 1024);
      const makeBlob = (mb) => {
        const parts = [];
        const count = Math.round((mb * 1024 * 1024) / dummyBuffer.byteLength);
        for (let i = 0; i < count; i++) parts.push(dummyBuffer);
        return parts;
      };
      const f1 = new File([new Blob(makeBlob(35), { type: 'application/vnd.android.package-archive' })], 'CyberRacing_v2.apk', { type: 'application/vnd.android.package-archive' });
      const f2 = new File([new Blob(makeBlob(65), { type: 'video/mp4' })], 'Desert_4K_HDR.mp4', { type: 'video/mp4' });
      selectedFiles = [...selectedFiles, f1, f2];
      renderSelectedFiles();
      updateSendButtonState();
    }

    function clearFiles() {
      selectedFiles = [];
      renderSelectedFiles();
      updateSendButtonState();
    }

    function renderSelectedFiles() {
      const container = document.getElementById('fileListContainer');
      container.innerHTML = '';
      selectedFiles.forEach((file, idx) => {
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5 text-xs';
        div.innerHTML = \`
          <div class="truncate max-w-xs text-slate-200 font-medium">\${file.name}</div>
          <div class="flex items-center gap-3 text-slate-400">
            <span>\${formatBytes(file.size)}</span>
            <button onclick="removeSelectedFile(\${idx})" class="text-rose-400 hover:text-rose-300">✕</button>
          </div>
        \`;
        container.appendChild(div);
      });
    }

    function removeSelectedFile(index) {
      selectedFiles.splice(index, 1);
      renderSelectedFiles();
      updateSendButtonState();
    }

    function updateSendButtonState() {
      const btn = document.getElementById('btnSendFiles');
      const text = document.getElementById('btnSendFilesText');
      const totalSize = selectedFiles.reduce((acc, f) => acc + f.size, 0);

      if (selectedFiles.length === 0) {
        btn.disabled = true;
        btn.className = 'w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-3 bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5 transition-all';
        text.textContent = 'اختر الملفات أولاً لبدء النقل';
      } else if (!dataConn || !dataConn.open) {
        btn.disabled = true;
        btn.className = 'w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-3 bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5 transition-all';
        text.textContent = 'بانتظار مسح الرمز من الجوال المستلم للبدء...';
      } else {
        btn.disabled = false;
        btn.className = 'w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-xl shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer';
        text.textContent = 'بدء نقل ' + selectedFiles.length + ' ملفات (' + formatBytes(totalSize) + ') ⚡';
      }
    }

    // Smart Compression Helper
    async function compressChunkIfNeeded(buffer, filename) {
      const ext = filename.split('.').pop().toLowerCase();
      if (['mp4', 'mkv', 'jpg', 'jpeg', 'png', 'zip', 'gz'].includes(ext)) {
        return { isCompressed: false, data: buffer };
      }
      if (typeof CompressionStream !== 'undefined' && buffer.byteLength > 2048) {
        try {
          const stream = new Response(buffer).body.pipeThrough(new CompressionStream('gzip'));
          const compressed = await new Response(stream).arrayBuffer();
          if (compressed.byteLength < buffer.byteLength * 0.9) {
            compressionSavingsTotal += (buffer.byteLength - compressed.byteLength);
            return { isCompressed: true, data: compressed };
          }
        } catch (e) {}
      }
      return { isCompressed: false, data: buffer };
    }

    async function decompressChunkIfNeeded(buffer, isCompressed) {
      if (isCompressed && typeof DecompressionStream !== 'undefined') {
        try {
          const stream = new Response(buffer).body.pipeThrough(new DecompressionStream('gzip'));
          return await new Response(stream).arrayBuffer();
        } catch (e) {}
      }
      return buffer;
    }

    // Packet Protocol & Chunking
    async function startSendingFiles() {
      if (!dataConn || !dataConn.open || selectedFiles.length === 0) return;
      isTransferring = true;
      compressionSavingsTotal = 0;
      switchToTransferView();

      const chunkSize = getChunkSize();
      transferFilesState = selectedFiles.map((file, idx) => ({
        id: 'f_' + idx + '_' + Date.now(),
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        file: file,
        receivedBytes: 0,
        progress: 0,
        status: 'pending'
      }));

      renderTransferFileList();

      dataConn.send({
        type: 'MANIFEST',
        files: transferFilesState.map(f => ({ id: f.id, name: f.name, size: f.size, type: f.type })),
        totalSize: selectedFiles.reduce((a, b) => a + b.size, 0),
        chunkSize: chunkSize,
        turbo: turboMode
      });

      startSpeedMeter(selectedFiles.reduce((a, b) => a + b.size, 0));

      for (let i = 0; i < transferFilesState.length; i++) {
        if (!isTransferring) break;
        await streamFileToReceiver(transferFilesState[i], chunkSize);
      }

      if (isTransferring) {
        dataConn.send({ type: 'TRANSFER_COMPLETE' });
        onTransferFinished();
      }
    }

    async function streamFileToReceiver(tf, chunkSize) {
      tf.status = 'transferring';
      updateTransferItem(tf);
      dataConn.send({ type: 'FILE_START', fileId: tf.id, name: tf.name, size: tf.size });

      let offset = 0;
      const file = tf.file;

      while (offset < file.size) {
        if (!isTransferring) break;

        const dc = dataConn.dataChannel;
        const watermark = chunkSize > 131072 ? 3 * 1024 * 1024 : 1024 * 1024;
        if (dc && dc.bufferedAmount > watermark) {
          await new Promise(r => setTimeout(r, 15));
        }

        const slice = file.slice(offset, offset + chunkSize);
        const rawBuf = await slice.arrayBuffer();
        const compressed = await compressChunkIfNeeded(rawBuf, tf.name);

        dataConn.send({ type: 'FILE_CHUNK', fileId: tf.id, isCompressed: compressed.isCompressed, data: compressed.data });

        offset += rawBuf.byteLength;
        tf.receivedBytes = offset;
        tf.progress = Math.min(100, Math.round((offset / tf.size) * 100));
        recordTransferred(rawBuf.byteLength);

        // Throttle UI update in Turbo Mode
        if (!turboMode || Math.random() < 0.25) {
          updateTransferItem(tf);
        }
      }

      if (isTransferring) {
        tf.status = 'completed';
        tf.progress = 100;
        dataConn.send({ type: 'FILE_COMPLETE', fileId: tf.id });
        updateTransferItem(tf);
      }
    }

    async function handleIncomingPacket(packet) {
      if (!packet || typeof packet !== 'object') return;

      if (packet.type === 'MANIFEST') {
        transferFilesState = packet.files.map(f => ({
          ...f,
          receivedChunks: [],
          receivedBytes: 0,
          progress: 0,
          status: 'pending'
        }));
        receiverSegments.clear();
        receiverBuffer.clear();
        switchToTransferView();
        renderTransferFileList();
        startSpeedMeter(packet.totalSize);
      } else if (packet.type === 'FILE_START') {
        const f = transferFilesState.find(x => x.id === packet.fileId);
        if (f) {
          f.status = 'transferring';
          f.receivedChunks = [];
          receiverSegments.set(packet.fileId, []);
          receiverBuffer.set(packet.fileId, []);
          updateTransferItem(f);
        }
      } else if (packet.type === 'FILE_CHUNK') {
        const f = transferFilesState.find(x => x.id === packet.fileId);
        if (f) {
          const rawBuf = await decompressChunkIfNeeded(packet.data, packet.isCompressed);
          
          if (turboMode) {
            // Memory batching in Turbo Mode: consolidate into Blobs every 16MB to save RAM
            let buf = receiverBuffer.get(packet.fileId) || [];
            buf.push(rawBuf);
            let bSize = buf.reduce((a, b) => a + b.byteLength, 0);
            if (bSize > 16 * 1024 * 1024) {
              const segs = receiverSegments.get(packet.fileId) || [];
              segs.push(new Blob(buf));
              receiverSegments.set(packet.fileId, segs);
              buf = [];
              receiverBuffer.set(packet.fileId, buf);
            }
          } else {
            f.receivedChunks.push(rawBuf);
          }

          f.receivedBytes += rawBuf.byteLength;
          f.progress = Math.min(100, Math.round((f.receivedBytes / f.size) * 100));
          recordTransferred(rawBuf.byteLength);

          if (!turboMode || Math.random() < 0.25) {
            updateTransferItem(f);
          }
        }
      } else if (packet.type === 'FILE_COMPLETE') {
        const f = transferFilesState.find(x => x.id === packet.fileId);
        if (f) {
          f.status = 'completed';
          f.progress = 100;
          let blob;
          if (turboMode) {
            const buf = receiverBuffer.get(packet.fileId) || [];
            const segs = receiverSegments.get(packet.fileId) || [];
            if (buf.length > 0) segs.push(new Blob(buf));
            blob = new Blob(segs, { type: f.type || 'application/octet-stream' });
            receiverSegments.delete(packet.fileId);
            receiverBuffer.delete(packet.fileId);
          } else {
            blob = new Blob(f.receivedChunks, { type: f.type || 'application/octet-stream' });
          }
          f.blobUrl = URL.createObjectURL(blob);
          updateTransferItem(f);
        }
      } else if (packet.type === 'TRANSFER_COMPLETE') {
        onTransferFinished();
      }
    }

    function switchToTransferView() {
      document.getElementById('viewHome').classList.add('hidden');
      document.getElementById('viewSender').classList.add('hidden');
      document.getElementById('viewReceiver').classList.add('hidden');
      document.getElementById('viewTransfer').classList.remove('hidden');
      
      const chunkKb = Math.round(getChunkSize() / 1024);
      document.getElementById('badgeChunkSize').textContent = 'حزم ' + chunkKb + 'KB ديناميكية';
      document.getElementById('badgeNetworkTier').textContent = networkTier === '5ghz' ? '5GHz Hotspot' : networkTier === '4g' ? '4G Hotspot' : networkTier === '3g' ? '3G Hotspot' : 'كشف تلقائي ذكي';
      document.getElementById('badgeTurbo').textContent = turboMode ? 'وضع Turbo (حماية المعالج)' : 'الوضع العادي';
      initIcons();
    }

    function renderTransferFileList() {
      const list = document.getElementById('transferFilesList');
      list.innerHTML = '';
      transferFilesState.forEach(f => {
        const div = document.createElement('div');
        div.id = 'tf_' + f.id;
        div.className = 'p-4 rounded-2xl border bg-slate-900/60 border-white/5 space-y-2';
        div.innerHTML = \`
          <div class="flex items-center justify-between text-xs">
            <span class="font-semibold text-slate-100 truncate max-w-xs">\${f.name}</span>
            <div class="flex items-center gap-2">
              <span id="prog_txt_\${f.id}" class="text-slate-400">\${formatBytes(f.size)}</span>
              <button id="dl_btn_\${f.id}" onclick="downloadSingleFile('\${f.id}')" class="hidden px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold">حفظ</button>
            </div>
          </div>
          <div class="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div id="bar_\${f.id}" class="h-full bg-emerald-500 transition-all duration-200" style="width: 0%"></div>
          </div>
        \`;
        list.appendChild(div);
      });
    }

    function updateTransferItem(tf) {
      const bar = document.getElementById('bar_' + tf.id);
      const progTxt = document.getElementById('prog_txt_' + tf.id);
      const dlBtn = document.getElementById('dl_btn_' + tf.id);
      if (bar) bar.style.width = tf.progress + '%';
      if (progTxt) {
        progTxt.textContent = tf.status === 'completed' ? 'مكتمل ✓' : formatBytes(tf.receivedBytes) + ' (' + tf.progress + '%)';
      }
      if (dlBtn && tf.blobUrl && tf.status === 'completed') {
        dlBtn.classList.remove('hidden');
      }
    }

    function downloadSingleFile(fileId) {
      const f = transferFilesState.find(x => x.id === fileId);
      if (!f || !f.blobUrl) return;
      const a = document.createElement('a');
      a.href = f.blobUrl;
      a.download = f.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }

    function downloadAllFiles() {
      transferFilesState.forEach((f, idx) => {
        if (f.blobUrl) {
          setTimeout(() => downloadSingleFile(f.id), idx * 250);
        }
      });
    }

    function onTransferFinished() {
      isTransferring = false;
      if (speedInterval) clearInterval(speedInterval);
      document.getElementById('speedVal').textContent = 'مكتمل';
      document.getElementById('timeRemainingVal').textContent = '0 ثانية';
      document.getElementById('completionBanner').classList.remove('hidden');
      document.getElementById('transferStatusHeadline').textContent = 'اكتمل نقل كافة الملفات بنجاح! 🚀';
      document.getElementById('masterProgressBar').style.width = '100%';
      document.getElementById('masterPercent').textContent = '100%';

      if (window.confetti) {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }
    }

    function cancelTransfer() {
      isTransferring = false;
      if (dataConn) {
        try { dataConn.send({ type: 'TRANSFER_CANCEL' }); } catch (e) {}
      }
      resetToHome();
    }

    // Speedometer
    function recordTransferred(bytes) {
      speedHistory.push({ time: Date.now(), bytes });
    }

    function startSpeedMeter(totalBytes) {
      speedHistory = [];
      let totalTransferred = 0;
      if (speedInterval) clearInterval(speedInterval);

      speedInterval = setInterval(() => {
        const now = Date.now();
        const cutoff = now - 2000;
        speedHistory = speedHistory.filter(h => h.time >= cutoff);

        const bytesWindow = speedHistory.reduce((a, b) => a + b.bytes, 0);
        const secWindow = speedHistory.length > 1 ? (now - speedHistory[0].time) / 1000 : 1;
        const bps = secWindow > 0 ? bytesWindow / secWindow : 0;
        const mbps = bps / (1024 * 1024);

        totalTransferred = transferFilesState.reduce((a, b) => a + b.receivedBytes, 0);
        const overallProg = totalBytes > 0 ? Math.min(100, (totalTransferred / totalBytes) * 100) : 0;
        const remainingBytes = Math.max(0, totalBytes - totalTransferred);
        const estSec = bps > 0 ? Math.ceil(remainingBytes / bps) : 0;

        document.getElementById('speedVal').textContent = mbps >= 1 ? mbps.toFixed(1) + ' م.ب/ث' : Math.round(bps / 1024) + ' ك.ب/ث';
        document.getElementById('totalTransferredVal').textContent = formatBytes(totalTransferred) + ' من ' + formatBytes(totalBytes);
        document.getElementById('masterPercent').textContent = overallProg.toFixed(1) + '%';
        document.getElementById('masterProgressBar').style.width = overallProg + '%';
        document.getElementById('timeRemainingVal').textContent = estSec > 0 ? estSec + ' ثانية' : 'لحظات...';

        if (compressionSavingsTotal > 0) {
          document.getElementById('compressionSavedVal').textContent = '+' + formatBytes(compressionSavingsTotal);
        }

        const completedCount = transferFilesState.filter(f => f.status === 'completed').length;
        document.getElementById('filesCompletedVal').textContent = completedCount + ' من ' + transferFilesState.length + ' ملف';
      }, 350);
    }

    // Benchmark Simulator
    function runLocalBenchmark() {
      closeSimulatorModal();
      currentRole = 'receiver';
      switchToTransferView();

      const f1Blob = new Blob(['Demo APK Data'], { type: 'application/vnd.android.package-archive' });
      const f2Blob = new Blob(['Demo 4K Video Data'], { type: 'video/mp4' });

      transferFilesState = [
        { id: 'b_1', name: 'Desert_Rally_Game_v3.apk', size: 85 * 1024 * 1024, receivedBytes: 0, progress: 0, status: 'pending', blobUrl: URL.createObjectURL(f1Blob) },
        { id: 'b_2', name: '4K_Drone_Safari.mp4', size: 125 * 1024 * 1024, receivedBytes: 0, progress: 0, status: 'pending', blobUrl: URL.createObjectURL(f2Blob) }
      ];

      renderTransferFileList();
      const totalBytes = transferFilesState.reduce((a, b) => a + b.size, 0);
      let transferred = 0;

      let simBps = 75 * 1024 * 1024;
      let label = '5GHz Hotspot';
      let chunkKb = 256;
      if (simSelectedTier === '4g') {
        simBps = 28 * 1024 * 1024;
        label = '4G Hotspot';
        chunkKb = 128;
      } else if (simSelectedTier === '3g') {
        simBps = 8.5 * 1024 * 1024;
        label = '3G Hotspot';
        chunkKb = 32;
      }

      document.getElementById('badgeChunkSize').textContent = 'حزم ' + chunkKb + 'KB ديناميكية';
      document.getElementById('badgeNetworkTier').textContent = label;
      document.getElementById('badgeTurbo').textContent = turboMode ? 'وضع Turbo (حماية المعالج)' : 'الوضع العادي';

      const tick = turboMode ? 140 : 80;
      const bytesPerTick = (simBps * tick) / 1000;
      let curIdx = 0;

      speedInterval = setInterval(() => {
        transferred += bytesPerTick;
        const curFile = transferFilesState[curIdx];
        if (curFile) {
          curFile.status = 'transferring';
          curFile.receivedBytes = Math.min(curFile.size, curFile.receivedBytes + bytesPerTick);
          curFile.progress = Math.min(100, Math.round((curFile.receivedBytes / curFile.size) * 100));
          updateTransferItem(curFile);
          if (curFile.receivedBytes >= curFile.size) {
            curFile.status = 'completed';
            curFile.progress = 100;
            updateTransferItem(curFile);
            curIdx++;
          }
        }

        const overallProg = Math.min(100, (transferred / totalBytes) * 100);
        const mbps = (simBps / (1024 * 1024)).toFixed(1);
        document.getElementById('speedVal').textContent = mbps + ' م.ب/ث';
        document.getElementById('totalTransferredVal').textContent = formatBytes(transferred) + ' من ' + formatBytes(totalBytes);
        document.getElementById('masterPercent').textContent = overallProg.toFixed(1) + '%';
        document.getElementById('masterProgressBar').style.width = overallProg + '%';
        const remSec = Math.max(0, Math.ceil((totalBytes - transferred) / simBps));
        document.getElementById('timeRemainingVal').textContent = remSec + ' ثانية';

        const saved = Math.round(transferred * 0.22);
        document.getElementById('compressionSavedVal').textContent = '+' + formatBytes(saved);

        const completedCount = transferFilesState.filter(f => f.status === 'completed').length;
        document.getElementById('filesCompletedVal').textContent = completedCount + ' من ' + transferFilesState.length + ' ملف';

        if (transferred >= totalBytes) {
          clearInterval(speedInterval);
          onTransferFinished();
        }
      }, tick);
    }

    // QR Scanner
    async function openScannerModal() {
      document.getElementById('modalScanner').classList.remove('hidden');
      initIcons();
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        scannerStream = stream;
        const video = document.getElementById('scannerVideo');
        video.srcObject = stream;
        video.play();
        scanQrLoop();
      } catch (e) {
        showError('تعذر فتح الكاميرا، يمكنك رفع لقطة شاشة للرمز بدلاً من ذلك.');
      }
    }

    function closeScannerModal() {
      if (scannerStream) {
        scannerStream.getTracks().forEach(t => t.stop());
        scannerStream = null;
      }
      if (scannerAnimFrame) cancelAnimationFrame(scannerAnimFrame);
      document.getElementById('modalScanner').classList.add('hidden');
    }

    function scanQrLoop() {
      const video = document.getElementById('scannerVideo');
      const canvas = document.getElementById('scannerCanvas');
      if (video.readyState === video.HAVE_ENOUGH_DATA && window.jsQR) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imgData.data, imgData.width, imgData.height);
        if (code && code.data) {
          let clean = code.data;
          if (clean.includes('connect=')) {
            clean = clean.split('connect=')[1].split('&')[0];
          }
          closeScannerModal();
          document.getElementById('receiverCodeInput').value = clean;
          connectByManualCode();
          return;
        }
      }
      scannerAnimFrame = requestAnimationFrame(scanQrLoop);
    }

    function handleQrScreenshot(e) {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imgData.data, imgData.width, imgData.height);
          if (code && code.data) {
            let clean = code.data;
            if (clean.includes('connect=')) clean = clean.split('connect=')[1].split('&')[0];
            closeScannerModal();
            document.getElementById('receiverCodeInput').value = clean;
            connectByManualCode();
          } else {
            showError('لم يتم العثور على رمز QR صالح في الصورة.');
          }
        };
        img.src = ev.target.result;
      };
      reader.readAsDataURL(file);
    }

    // Modal Helpers
    function openHotspotModal() {
      document.getElementById('modalHotspot').classList.remove('hidden');
      initIcons();
    }
    function closeHotspotModal() {
      document.getElementById('modalHotspot').classList.add('hidden');
    }
    function openSimulatorModal() {
      document.getElementById('modalSimulator').classList.remove('hidden');
      initIcons();
    }
    function closeSimulatorModal() {
      document.getElementById('modalSimulator').classList.add('hidden');
    }

    function copyCode() {
      navigator.clipboard.writeText(localShortCode.replace('-', ''));
      alert('تم نسخ الكود: ' + localShortCode);
    }

    function downloadSelfHtml() {
      const fullHtml = '<!doctype html>\\n' + document.documentElement.outerHTML;
      const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'index.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  </script>
</body>
</html>`;
