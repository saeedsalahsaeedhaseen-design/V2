/**
 * Smart streaming compression utility using native CompressionStream & DecompressionStream.
 * Zero external libraries needed; high throughput and minimal CPU overhead.
 */

// Extensions known to already have high-entropy compression where re-compressing wastes CPU
const ALREADY_COMPRESSED_EXTENSIONS = new Set([
  'mp4', 'mkv', 'avi', 'mov', 'webm', 'wmv', 'flv',
  'jpg', 'jpeg', 'png', 'webp', 'gif', 'heic', 'avif',
  'mp3', 'aac', 'ogg', 'm4a', 'flac',
  'zip', 'rar', '7z', 'gz', 'bz2', 'xz', 'tar.gz',
]);

export function isFileCompressible(filename: string, mimeType?: string): boolean {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  if (ALREADY_COMPRESSED_EXTENSIONS.has(ext)) {
    return false;
  }
  if (mimeType?.startsWith('video/') || mimeType?.startsWith('image/')) {
    // SVGs and BMPs are compressible
    if (ext === 'svg' || ext === 'bmp') return true;
    return false;
  }
  return true;
}

export async function canCompressChunk(chunk: ArrayBuffer): Promise<{ shouldCompress: boolean; compressed?: ArrayBuffer }> {
  // If native CompressionStream is not available
  if (typeof CompressionStream === 'undefined') {
    return { shouldCompress: false };
  }

  // Small chunks (< 1KB) have too much gzip header overhead
  if (chunk.byteLength < 1024) {
    return { shouldCompress: false };
  }

  try {
    const stream = new Response(chunk).body!.pipeThrough(new CompressionStream('gzip'));
    const compressedBuffer = await new Response(stream).arrayBuffer();

    // Check if compression achieved at least 8% reduction
    if (compressedBuffer.byteLength < chunk.byteLength * 0.92) {
      return { shouldCompress: true, compressed: compressedBuffer };
    }
  } catch (e) {
    console.warn('Compression probe skipped', e);
  }

  return { shouldCompress: false };
}

export async function compressBuffer(buffer: ArrayBuffer): Promise<ArrayBuffer> {
  const stream = new Response(buffer).body!.pipeThrough(new CompressionStream('gzip'));
  return await new Response(stream).arrayBuffer();
}

export async function decompressBuffer(buffer: ArrayBuffer): Promise<ArrayBuffer> {
  const stream = new Response(buffer).body!.pipeThrough(new DecompressionStream('gzip'));
  return await new Response(stream).arrayBuffer();
}
