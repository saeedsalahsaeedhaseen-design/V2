import { NetworkTier, NetworkProfile } from '../types/transfer';

export const NETWORK_TIERS: Record<'5ghz' | '4g' | '3g', Omit<NetworkProfile, 'tier' | 'detectedTier' | 'rttMs'>> = {
  '5ghz': {
    label: 'نقطة اتصال 5GHz فائقة',
    chunkSize: 256 * 1024, // 256 KB chunks for gigabit LAN / 5GHz
    bufferWatermark: 4 * 1024 * 1024, // 4 MB
    description: 'أقصى سرعة نقل محلي P2P عبر التردد العالي، حزم ضخمة 256KB',
  },
  '4g': {
    label: 'نقطة اتصال 4G / واي فاي سريع',
    chunkSize: 128 * 1024, // 128 KB chunks
    bufferWatermark: 2 * 1024 * 1024, // 2 MB
    description: 'أداء متوازن ومستقر لشبكات 4G والتردد 2.4GHz، حزم 128KB',
  },
  '3g': {
    label: 'نقطة اتصال 3G / شبكة ضعيفة',
    chunkSize: 32 * 1024, // 32 KB chunks to avoid packet drop & memory pressure
    bufferWatermark: 512 * 1024, // 512 KB
    description: 'حزم مرنة 32KB تمنع انقطاع النقل نهائياً على الأجهزة القديمة أو الضعيفة',
  },
};

export function detectNetworkCondition(rttMs: number = 0): '5ghz' | '4g' | '3g' {
  // 1. Check navigator.connection if available
  const navConn = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
  if (navConn) {
    const effType = navConn.effectiveType; // 'slow-2g', '2g', '3g', '4g'
    const downlink = navConn.downlink || 10; // Mb/s

    if (rttMs > 0) {
      if (rttMs < 20 && downlink >= 25) return '5ghz';
      if (rttMs < 70 || effType === '4g') return '4g';
      return '3g';
    }

    if (effType === '4g' && downlink >= 30) return '5ghz';
    if (effType === '4g' || effType === '3g') return '4g';
    return '3g';
  }

  // 2. Fallback to measured RTT if connection API not supported (e.g. iOS Safari)
  if (rttMs > 0) {
    if (rttMs < 25) return '5ghz';
    if (rttMs < 80) return '4g';
    return '3g';
  }

  // Default optimal tier
  return '5ghz';
}

export function getActiveProfile(tierSetting: NetworkTier, measuredRtt: number = 0): NetworkProfile {
  const detected = detectNetworkCondition(measuredRtt);
  const effectiveTier = tierSetting === 'auto' ? detected : tierSetting;
  const config = NETWORK_TIERS[effectiveTier];

  return {
    tier: tierSetting,
    detectedTier: detected,
    label: config.label,
    chunkSize: config.chunkSize,
    bufferWatermark: config.bufferWatermark,
    description: config.description,
    rttMs: measuredRtt,
  };
}
