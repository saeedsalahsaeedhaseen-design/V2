export type TransferRole = 'idle' | 'sender' | 'receiver';

export type TransferStatus = 'idle' | 'connecting' | 'connected' | 'transferring' | 'completed' | 'error' | 'cancelled';

export type NetworkTier = '5ghz' | '4g' | '3g' | 'auto';

export interface NetworkProfile {
  tier: NetworkTier;
  detectedTier: '5ghz' | '4g' | '3g';
  label: string;
  chunkSize: number; // in bytes: 256KB for 5GHz, 128KB for 4G, 32KB for 3G
  bufferWatermark: number;
  description: string;
  rttMs: number;
}

export interface TurboSettings {
  enabled: boolean; // Turbo Mode for low-end / weak devices
  uiThrottleMs: number; // 250ms instead of immediate per-chunk re-renders
  memoryBatchMb: number; // Consolidate chunks into 16MB blocks
  disableAnimations: boolean;
}

export interface TransferFile {
  id: string;
  name: string;
  size: number;
  type: string;
  lastModified?: number;
  file?: File; // Present on sender
  receivedChunks?: ArrayBuffer[];
  receivedBytes: number;
  progress: number; // 0 to 100
  status: 'pending' | 'transferring' | 'completed' | 'error';
  blobUrl?: string;
  downloaded?: boolean;
  isCompressed?: boolean;
  originalSize?: number;
  compressionSavingsBytes?: number;
}

export interface SpeedStats {
  bytesPerSecond: number;
  formattedSpeed: string;
  estimatedSecondsRemaining: number;
  totalTransferredBytes: number;
  totalBytes: number;
  overallProgress: number;
  networkTierLabel: string;
  activeChunkSizeKB: number;
  turboActive: boolean;
  compressionSavedBytes: number;
}

export type PacketType = 
  | 'HANDSHAKE'
  | 'MANIFEST'
  | 'FILE_START'
  | 'FILE_CHUNK'
  | 'FILE_COMPLETE'
  | 'TRANSFER_COMPLETE'
  | 'TRANSFER_CANCEL'
  | 'PING'
  | 'PONG';

export interface PacketManifest {
  type: 'MANIFEST';
  files: Array<{
    id: string;
    name: string;
    size: number;
    type: string;
    isCompressed?: boolean;
    originalSize?: number;
  }>;
  totalSize: number;
  turboEnabled?: boolean;
  chunkSize: number;
}

export interface PacketFileStart {
  type: 'FILE_START';
  fileId: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  totalChunks: number;
  chunkSize: number;
  isCompressed?: boolean;
  originalSize?: number;
}

export interface PacketFileChunk {
  type: 'FILE_CHUNK';
  fileId: string;
  chunkIndex: number;
  totalChunks: number;
  isCompressed?: boolean;
  data: ArrayBuffer;
}

export interface PacketFileComplete {
  type: 'FILE_COMPLETE';
  fileId: string;
  isCompressed?: boolean;
}

export interface PacketTransferComplete {
  type: 'TRANSFER_COMPLETE';
}

export interface PacketCancel {
  type: 'TRANSFER_CANCEL';
  reason?: string;
}

export interface PacketPing {
  type: 'PING';
  timestamp: number;
}

export interface PacketPong {
  type: 'PONG';
  timestamp: number;
}

export type TransferPacket =
  | PacketManifest
  | PacketFileStart
  | PacketFileChunk
  | PacketFileComplete
  | PacketTransferComplete
  | PacketCancel
  | PacketPing
  | PacketPong;
