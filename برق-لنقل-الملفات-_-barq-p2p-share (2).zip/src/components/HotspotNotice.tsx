import React from 'react';
import { Wifi, Radio, ChevronLeft, Zap, Cpu, Sparkles } from 'lucide-react';
import { NetworkTier } from '../types/transfer';

interface HotspotNoticeProps {
  onLearnMore: () => void;
  networkTier: NetworkTier;
  onNetworkTierChange: (tier: NetworkTier) => void;
  turboMode: boolean;
  onTurboModeToggle: (enabled: boolean) => void;
}

export const HotspotNotice: React.FC<HotspotNoticeProps> = ({ 
  onLearnMore, 
  networkTier, 
  onNetworkTierChange,
  turboMode,
  onTurboModeToggle,
}) => {
  return (
    <div className="space-y-3">
      {/* Main Notice Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-teal-950/40 border border-emerald-500/20 p-4 sm:p-4.5 text-slate-200 shadow-xl shadow-emerald-950/20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0 text-emerald-400">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div className="space-y-0.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                  توافق ذكي مع 5GHz و 4G و 3G Hotspot
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                  تجزئة ديناميكية + ضغط ذكي
                </span>
              </div>
              <p className="text-sm font-medium text-slate-100 leading-relaxed">
                يتعرف التطبيق تلقائياً على قوة الشبكة (5GHz أو 4G أو 3G) ويضبط حجم الحزم ويضغط البيانات تلقائياً، مع وضع <strong>Turbo</strong> لحماية الأجهزة الضعيفة من التهنيج.
              </p>
            </div>
          </div>

          <button
            onClick={onLearnMore}
            className="self-end sm:self-center shrink-0 flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:text-emerald-200 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl transition-all active:scale-95 whitespace-nowrap"
          >
            <span>دليل الشبكات</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Network Tier Controls & Turbo Emergency Switch */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/70 border border-white/8 text-xs">
        {/* Network Tier Mode Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-slate-400 shrink-0 font-medium flex items-center gap-1">
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span>نمط الشبكة:</span>
          </span>
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-white/5 shrink-0">
            <button
              type="button"
              onClick={() => onNetworkTierChange('auto')}
              className={`px-2.5 py-1 rounded-lg transition-all font-medium whitespace-nowrap ${
                networkTier === 'auto'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              كشف تلقائي ذكي
            </button>
            <button
              type="button"
              onClick={() => onNetworkTierChange('5ghz')}
              className={`px-2.5 py-1 rounded-lg transition-all font-medium whitespace-nowrap ${
                networkTier === '5ghz'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              5GHz (256KB)
            </button>
            <button
              type="button"
              onClick={() => onNetworkTierChange('4g')}
              className={`px-2.5 py-1 rounded-lg transition-all font-medium whitespace-nowrap ${
                networkTier === '4g'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              4G (128KB)
            </button>
            <button
              type="button"
              onClick={() => onNetworkTierChange('3g')}
              className={`px-2.5 py-1 rounded-lg transition-all font-medium whitespace-nowrap ${
                networkTier === '3g'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              3G (32KB)
            </button>
          </div>
        </div>

        {/* Turbo Mode Switch for Weak Devices */}
        <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0">
          <div className="flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <div>
              <span className="font-bold text-white">وضع التوربو للطوارئ</span>
              <span className="text-[10px] text-slate-400 mr-1.5 hidden md:inline">(توفير المعالج للأجهزة الضعيفة)</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onTurboModeToggle(!turboMode)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              turboMode ? 'bg-amber-500' : 'bg-slate-800'
            }`}
            role="switch"
            aria-checked={turboMode}
            title="تفعيل وضع التوربو لتقليل استهلاك المعالج وتجميع الحزم"
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                turboMode ? '-translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
