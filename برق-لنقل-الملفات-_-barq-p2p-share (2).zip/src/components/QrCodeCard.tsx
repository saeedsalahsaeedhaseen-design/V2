import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, Share2, QrCode, RefreshCw, Smartphone, Radio } from 'lucide-react';

interface QrCodeCardProps {
  shortCode: string;
  isConnected: boolean;
  onRefreshCode?: () => void;
}

export const QrCodeCard: React.FC<QrCodeCardProps> = ({ shortCode, isConnected, onRefreshCode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Generate shareable URL
  const cleanCode = shortCode.replace('-', '');
  const shareUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?connect=${cleanCode}`
    : `https://barq.app/?connect=${cleanCode}`;

  useEffect(() => {
    if (canvasRef.current && shortCode) {
      QRCode.toCanvas(
        canvasRef.current,
        shareUrl,
        {
          width: 200,
          margin: 1.5,
          color: {
            dark: '#030712',
            light: '#FFFFFF',
          },
        },
        (error) => {
          if (error) console.error('QR code generation error:', error);
        }
      );
    }
  }, [shareUrl, shortCode]);

  const copyCodeToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(cleanCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } catch (e) {
      console.warn('Copy failed', e);
    }
  };

  const copyLinkToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (e) {
      console.warn('Copy link failed', e);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'برق | نقل ملفات سريع عبر WebRTC',
          text: `امسح رمز QR أو استخدم كود الاتصال ${shortCode} لاستلام الملفات بسرعة فائقة`,
          url: shareUrl,
        });
      } catch (e) {
        copyLinkToClipboard();
      }
    } else {
      copyLinkToClipboard();
    }
  };

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-slate-900/50 border border-white/10 p-5 sm:p-6 space-y-5">
      {/* Status banner */}
      <div className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
        isConnected 
          ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300' 
          : 'bg-slate-800/60 border-white/5 text-slate-300'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <Radio className={`w-4 h-4 ${isConnected ? 'text-emerald-400' : 'text-amber-400 animate-pulse'}`} />
            {!isConnected && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            )}
          </div>
          <span className="text-xs sm:text-sm font-medium">
            {isConnected ? 'تم الاتصال بالجوال المستلم بنجاح! ⚡' : 'بانتظار مسح الرمز من الجوال المستلم...'}
          </span>
        </div>

        {onRefreshCode && !isConnected && (
          <button
            onClick={onRefreshCode}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            title="توليد كود جديد"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* QR Code and Pin Split */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center">
        {/* QR Canvas Box */}
        <div className="flex flex-col items-center justify-center p-4 bg-white rounded-2xl shadow-xl shadow-black/40">
          <canvas ref={canvasRef} className="rounded-lg max-w-[180px] h-auto" />
          <p className="text-[11px] font-semibold text-slate-800 mt-2 flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
            <span>امسح الرمز بكاميرا الجوال المستلم</span>
          </p>
        </div>

        {/* Short Code & Actions */}
        <div className="space-y-4 text-center sm:text-right">
          <div>
            <span className="text-xs text-slate-400 font-medium">كود الاتصال السريع:</span>
            <div className="mt-1 flex items-center justify-center sm:justify-start gap-2">
              <span className="text-2xl sm:text-3xl font-mono font-bold tracking-widest text-emerald-400 bg-emerald-500/10 px-3.5 py-1.5 rounded-xl border border-emerald-500/25">
                {shortCode || '--- ---'}
              </span>
              <button
                onClick={copyCodeToClipboard}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-white/5 transition-all active:scale-95"
                title="نسخ كود الاتصال"
              >
                {copiedCode ? <Check className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
            {copiedCode && (
              <p className="text-[11px] text-emerald-400 mt-1">تم نسخ الكود للحافظة!</p>
            )}
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/5 transition-all active:scale-95"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة الرابط</span>
            </button>

            <button
              onClick={copyLinkToClipboard}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/5 transition-all active:scale-95"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>نسخ الرابط</span>
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            بمجرد مسح الرمز أو إدخال الكود في الجوال الثاني المتصل بنفس الشبكة، سيبدأ الاتصال المباشر الفوري.
          </p>
        </div>
      </div>
    </div>
  );
};
