import React, { useState } from 'react';
import { X, Smartphone, Wifi, Zap, CheckCircle2, AlertCircle, Cpu, Layers, Sparkles } from 'lucide-react';

interface HotspotGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HotspotGuideModal: React.FC<HotspotGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'networks' | 'android' | 'ios' | 'turbo'>('networks');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-[#0E1524] border border-white/10 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-white/8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">دليل الشبكات الذكي ونظام التوربو</h3>
              <p className="text-xs text-slate-400">توافق كامل مع 5GHz و 4G و 3G Hotspot مع حماية الأجهزة الضعيفة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="px-6 pt-4 pb-2">
          <div className="grid grid-cols-4 p-1 bg-slate-900/80 rounded-xl border border-white/5 text-xs">
            <button
              onClick={() => setActiveTab('networks')}
              className={`py-2 px-2 rounded-lg font-medium transition-all text-center ${
                activeTab === 'networks'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              مقارنة الشبكات
            </button>
            <button
              onClick={() => setActiveTab('android')}
              className={`py-2 px-2 rounded-lg font-medium transition-all text-center ${
                activeTab === 'android'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              أندرويد
            </button>
            <button
              onClick={() => setActiveTab('ios')}
              className={`py-2 px-2 rounded-lg font-medium transition-all text-center ${
                activeTab === 'ios'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              آيفون
            </button>
            <button
              onClick={() => setActiveTab('turbo')}
              className={`py-2 px-2 rounded-lg font-medium transition-all text-center ${
                activeTab === 'turbo'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              نظام Turbo
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-300">
          {activeTab === 'networks' && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between text-white font-semibold">
                  <span className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span>نقطة اتصال 5GHz (السرعة القصوى)</span>
                  </span>
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">حزم 256KB</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  مثالية لنقل ألعاب وتطبيقات APK الكبيرة والأفلام 4K في ثوانٍ. سرعة تصل إلى 80-100 ميجابايت/ثانية.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-sky-500/30 space-y-2">
                <div className="flex items-center justify-between text-white font-semibold">
                  <span className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
                    <span>نقطة اتصال 4G / واي فاي عادي 2.4GHz</span>
                  </span>
                  <span className="text-xs font-mono text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded">حزم 128KB</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  تعمل بكفاءة وتوازن في كل الظروف وعلى أبعاد أطول. تجزئة مرنة وسريعة تضمن استقرار النقل.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between text-white font-semibold">
                  <span className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    <span>نقطة اتصال 3G / شبكة ضعيفة</span>
                  </span>
                  <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">حزم 32KB</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  تعتمد حزم صغيرة ودقيقة 32KB لمنع انقطاع النقل نهائياً وحماية أجهزة الهواتف القديمة من امتلاء الذاكرة المؤقتة.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-xs text-emerald-200 leading-relaxed">
                  <strong>الضغط الذكي التلقائي:</strong> يكتشف التطبيق الملفات القابلة للضغط ويضغطها لحظياً على المعالج قبل إرسالها لتقليص حجم النقل بنسبة تصل إلى 40%، بينما يتخطى تلقائياً الفيديوهات المضغوطة لتوفير طاقة المعالج.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'android' && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">1</span>
                  <span>تشغيل نقطة الاتصال في أندرويد</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  افتح <strong>الإعدادات</strong> ← <strong>الاتصالات</strong> ← <strong>نقطة اتصال الهواتف المحمولة</strong>.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">2</span>
                  <span>تحديد التردد المناسب</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  اضغط <strong>تهيئة</strong> واختر <strong>5.0 GHz</strong> للسرعة القصوى، أو اتركها على <strong>2.4 GHz (4G)</strong> للتوافق مع الهواتف القديمة.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">3</span>
                  <span>اتصال الجوال المستلم</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  اتصل بشبكة الواي فاي من الجوال الآخر؛ لن يتم استهلاك أي باقة إنترنت لأن النقل محلي P2P بالكامل.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'ios' && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">1</span>
                  <span>نقطة اتصال شخصية في iPhone</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  اذهب إلى <strong>الإعدادات</strong> ← <strong>نقطة اتصال شخصية (Personal Hotspot)</strong> وقم بتفعيلها.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">2</span>
                  <span>أقصى قدر من التوافق (Compatibility)</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  للحصول على سرعة 5GHz القصوى: <strong>أوقف</strong> خيار أقصى قدر من التوافق.<br />
                  إذا كان الجوال المستلم قديماً ولا يرى الشبكة: <strong>شغّل</strong> هذا الخيار للتحويل لتردد 2.4GHz.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">3</span>
                  <span>البدء والمسح الفوري</span>
                </div>
                <p className="text-xs text-slate-400 pr-8">
                  اتصل بنقطة الاتصال من الجوال الثاني، ثم امسح رمز QR لبدء النقل.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'turbo' && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold">
                  <Cpu className="w-5 h-5 text-amber-400" />
                  <span>ما هو نظام التوربو للطوارئ (Turbo Mode)؟</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  تمت هندسته خصيصاً لحماية الأجهزة الضعيفة أو القديمة من التجمد أو التهنيج عند استقبال ملفات ضخمة (ألعاب 2GB أو فيديوهات 4K طويلة).
                </p>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-3 rounded-lg bg-slate-900/60 border border-white/5 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white">تجميع الذاكرة الذكي (16MB Blocks):</strong>
                    <p className="text-slate-400 mt-0.5">يمنع تراكم آلاف الحزم في ذاكرة الرام عبر دمجها دورياً في كتل، مما يخفف الحمل على الجوال بنسبة 70%.</p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-900/60 border border-white/5 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white">تقليل تحديثات الشاشة (UI Throttle):</strong>
                    <p className="text-slate-400 mt-0.5">يحد من إعادة رسم الواجهة في أجزاء الثانية ويكرس قدرات المعالج لاستقبال البيانات من كرت الواي فاي مباشرة.</p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-900/60 border border-white/5 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white">تعليق المؤثرات الثقيلة:</strong>
                    <p className="text-slate-400 mt-0.5">يقوم بإيقاف المؤثرات الحركية تلقائياً أثناء النقل النشط لضمان انسيابية الجهاز المستلم بالكامل.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-white/8 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors"
          >
            فهمت، إغلاق الدليل
          </button>
        </div>
      </div>
    </div>
  );
};
