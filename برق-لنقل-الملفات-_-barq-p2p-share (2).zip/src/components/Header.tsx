import React from 'react';
import { Zap, Wifi, HelpCircle, Download } from 'lucide-react';

interface HeaderProps {
  onOpenHotspotGuide: () => void;
  onOpenSimulator: () => void;
  onDownloadHtml: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenHotspotGuide, onOpenSimulator, onDownloadHtml }) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-[#080C14]/90 backdrop-blur-md border-b border-white/8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Zap className="w-5 h-5 text-white stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-bold tracking-tight text-white">بَـرْق</span>
              <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">P2P</span>
            </div>
            <p className="text-[10px] text-slate-400 -mt-0.5">نقل فائق السرعة عبر 5GHz</p>
          </div>
        </div>

        {/* Zone 2: Navigation Badges / Info */}
        <nav className="hidden md:flex items-center gap-6 text-xs text-slate-300">
          <div className="flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span>نقل مباشر محلي (بدون إنترنت)</span>
          </div>
          <span className="text-white/20">·</span>
          <span>تقنية WebRTC المباشرة</span>
          <span className="text-white/20">·</span>
          <span>تجزئة آمنة للملفات الضخمة</span>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2">
          {/* Prominent Download index.html button requested by user */}
          <button
            onClick={onDownloadHtml}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 rounded-lg shadow-md shadow-emerald-500/20 transition-all active:scale-95 whitespace-nowrap"
            title="تنزيل كود ملف index.html المستقل بالكامل إلى جهازك"
          >
            <Download className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>تنزيل ملف index.html</span>
          </button>

          <button
            onClick={onOpenSimulator}
            className="hidden sm:inline-flex px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 rounded-lg border border-white/5 transition-colors whitespace-nowrap"
            title="تجربة النقل السريع محلياً لاختبار السرعة"
          >
            اختبار السرعة
          </button>
          
          <button
            onClick={onOpenHotspotGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-lg transition-all active:scale-95 whitespace-nowrap"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>إرشادات 5GHz</span>
          </button>
        </div>
      </div>
    </header>
  );
};
