import React, { useState } from 'react';
import { X, Play, Zap, ShieldCheck, Cpu, Wifi, Sparkles } from 'lucide-react';
import { SpeedStats, TransferFile, NetworkTier } from '../types/transfer';

interface SimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRunSimulation: (
    files: TransferFile[],
    networkTier: NetworkTier,
    turboMode: boolean,
    onProgressUpdate: (stats: SpeedStats, files: TransferFile[]) => void
  ) => void;
}

export const SimulatorModal: React.FC<SimulatorModalProps> = ({ isOpen, onClose, onRunSimulation }) => {
  const [selectedDemo, setSelectedDemo] = useState<'game' | 'video' | 'mixed'>('mixed');
  const [selectedNetwork, setSelectedNetwork] = useState<NetworkTier>('5ghz');
  const [simTurboMode, setSimTurboMode] = useState<boolean>(true);

  if (!isOpen) return null;

  const handleStart = () => {
    let demoFiles: TransferFile[] = [];

    if (selectedDemo === 'game') {
      demoFiles = [
        {
          id: 'demo_apk_1',
          name: 'Combat_Strike_Arena_v3.2.0.apk',
          size: 142 * 1024 * 1024,
          type: 'application/vnd.android.package-archive',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
          isCompressed: true,
        },
        {
          id: 'demo_apk_patch',
          name: 'Game_Patch_Assets_HighRes.obb',
          size: 88 * 1024 * 1024,
          type: 'application/octet-stream',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
          isCompressed: true,
        },
      ];
    } else if (selectedDemo === 'video') {
      demoFiles = [
        {
          id: 'demo_vid_1',
          name: 'Drone_4K_Desert_Safari_60FPS.mp4',
          size: 215 * 1024 * 1024,
          type: 'video/mp4',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
        },
      ];
    } else {
      demoFiles = [
        {
          id: 'demo_apk',
          name: 'Asphalt_Nitro_Racing.apk',
          size: 78 * 1024 * 1024,
          type: 'application/vnd.android.package-archive',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
          isCompressed: true,
        },
        {
          id: 'demo_vid',
          name: 'Family_Trip_4K_HDR.mp4',
          size: 135 * 1024 * 1024,
          type: 'video/mp4',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
        },
        {
          id: 'demo_doc',
          name: 'Engineering_CAD_Schematics.zip',
          size: 32 * 1024 * 1024,
          type: 'application/zip',
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
        },
      ];
    }

    onClose();

    // Create mock blobs
    demoFiles.forEach((file) => {
      const dummyBlob = new Blob([`Dummy data content for ${file.name}`], { type: file.type });
      file.blobUrl = URL.createObjectURL(dummyBlob);
    });

    onRunSimulation(demoFiles, selectedNetwork, simTurboMode, () => {});
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#0C121F] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-white/8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">محاكي السرعة والشبكات (Benchmark)</h3>
              <p className="text-xs text-slate-400">اختبر 5GHz و 4G و 3G ونظام Turbo محلياً</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-sm text-slate-300">
          {/* Network Tier Simulator Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 block flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              <span>اختر نوع الشبكة للمحاكاة:</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedNetwork('5ghz')}
                className={`p-3 rounded-xl border text-center transition-all ${
                  selectedNetwork === '5ghz'
                    ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">5GHz Hotspot</div>
                <div className="text-[10px] text-emerald-400 mt-1 font-mono">حزم 256KB (~75 MB/s)</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedNetwork('4g')}
                className={`p-3 rounded-xl border text-center transition-all ${
                  selectedNetwork === '4g'
                    ? 'border-sky-500 bg-sky-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">4G Hotspot</div>
                <div className="text-[10px] text-sky-400 mt-1 font-mono">حزم 128KB (~28 MB/s)</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedNetwork('3g')}
                className={`p-3 rounded-xl border text-center transition-all ${
                  selectedNetwork === '3g'
                    ? 'border-amber-500 bg-amber-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">3G Hotspot</div>
                <div className="text-[10px] text-amber-400 mt-1 font-mono">حزم 32KB (~8 MB/s)</div>
              </button>
            </div>
          </div>

          {/* Select Demo Bundle */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">اختر حزمة الملفات للتجربة:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedDemo('mixed')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedDemo === 'mixed'
                    ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">حزمة متنوعة</div>
                <div className="text-[10px] text-emerald-400 mt-1 font-mono">245 MB</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedDemo('game')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedDemo === 'game'
                    ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">لعبة APK + OBB</div>
                <div className="text-[10px] text-emerald-400 mt-1 font-mono">230 MB</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedDemo('video')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedDemo === 'video'
                    ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                    : 'border-white/5 bg-slate-900/50 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs">فيديو 4K كبير</div>
                <div className="text-[10px] text-emerald-400 mt-1 font-mono">215 MB</div>
              </button>
            </div>
          </div>

          {/* Turbo Mode Switch in simulator */}
          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-white/8 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <span className="text-xs font-bold text-white block">تفعيل وضع التوربو (Turbo Mode)</span>
                <span className="text-[10px] text-slate-400">تجميع الذاكرة في كتل 16MB وتخفيف استهلاك المعالج</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSimTurboMode(!simTurboMode)}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                simTurboMode ? 'bg-amber-500' : 'bg-slate-800'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  simTurboMode ? '-translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-white/8 bg-slate-950/40 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs"
          >
            إلغاء
          </button>

          <button
            onClick={handleStart}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>بدء المحاكاة الآن</span>
          </button>
        </div>
      </div>
    </div>
  );
};
