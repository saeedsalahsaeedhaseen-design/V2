import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Zap, 
  Download, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  XOctagon, 
  FileCheck, 
  HardDrive,
  Film,
  Package,
  FileArchive,
  Image as ImageIcon,
  FileText,
  File,
  Sparkles,
  Cpu,
  Layers,
  Wifi
} from 'lucide-react';
import { TransferFile, SpeedStats, TransferRole } from '../types/transfer';
import { formatFileSize, formatDuration, getFileCategory, FileCategory } from '../utils/formatters';

interface TransferProgressViewProps {
  role: TransferRole;
  files: TransferFile[];
  speedStats: SpeedStats;
  isCompleted: boolean;
  onCancel: () => void;
  onReset: () => void;
}

export const TransferProgressView: React.FC<TransferProgressViewProps> = ({
  role,
  files,
  speedStats,
  isCompleted,
  onCancel,
  onReset,
}) => {
  // Fire confetti upon full completion
  useEffect(() => {
    if (isCompleted) {
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#10b981', '#14b8a6', '#06b6d4', '#f59e0b', '#3b82f6'],
        });
      } catch (e) {}
    }
  }, [isCompleted]);

  const handleDownloadFile = (file: TransferFile) => {
    if (!file.blobUrl) return;
    const a = document.createElement('a');
    a.href = file.blobUrl;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadAll = () => {
    files.forEach((file, index) => {
      if (file.blobUrl && file.status === 'completed') {
        setTimeout(() => {
          handleDownloadFile(file);
        }, index * 250);
      }
    });
  };

  const getIconForCategory = (cat: FileCategory) => {
    switch (cat) {
      case 'apk': return <Package className="w-5 h-5 text-emerald-400" />;
      case 'video': return <Film className="w-5 h-5 text-sky-400" />;
      case 'image': return <ImageIcon className="w-5 h-5 text-amber-400" />;
      case 'archive': return <FileArchive className="w-5 h-5 text-purple-400" />;
      case 'document': return <FileText className="w-5 h-5 text-rose-400" />;
      default: return <File className="w-5 h-5 text-slate-400" />;
    }
  };

  const completedCount = files.filter((f) => f.status === 'completed').length;
  const currentSpeedMBps = speedStats.bytesPerSecond / (1024 * 1024);

  return (
    <div className="space-y-6">
      {/* Top Live Metrics Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#0F172A] to-[#0A0F1D] border border-white/10 p-6 shadow-2xl space-y-6">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Speedometer Circle & Current Speed */}
          <div className="flex items-center gap-5">
            <div className="relative w-24 h-24 rounded-full bg-slate-900 border-2 border-emerald-500/30 flex flex-col items-center justify-center shadow-lg shadow-emerald-500/10">
              {!isCompleted && currentSpeedMBps > 0 && (
                <div className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-25" />
              )}
              <Zap className={`w-6 h-6 ${isCompleted ? 'text-emerald-400' : 'text-emerald-400 animate-bounce'}`} />
              <span className="text-xs font-semibold text-slate-400 mt-1">السرعة الحالية</span>
            </div>

            <div className="space-y-1.5 text-right">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight text-white tabular-nums">
                  {isCompleted ? 'مكتمل' : speedStats.formattedSpeed}
                </span>
                {!isCompleted && (
                  <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    مباشر P2P
                  </span>
                )}
              </div>

              {/* Dynamic network, chunk size and turbo badges */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-medium flex items-center gap-1 border border-white/5">
                  <Wifi className="w-3 h-3 text-emerald-400" />
                  <span>{speedStats.networkTierLabel || '5GHz / 4G'}</span>
                </span>

                <span className="px-2 py-0.5 rounded-md bg-slate-800 text-cyan-300 font-mono flex items-center gap-1 border border-white/5">
                  <Layers className="w-3 h-3 text-cyan-400" />
                  <span>حزم {speedStats.activeChunkSizeKB || 256}KB ديناميكية</span>
                </span>

                {speedStats.turboActive && (
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-semibold flex items-center gap-1 border border-amber-500/30">
                    <Cpu className="w-3 h-3 text-amber-400" />
                    <span>وضع Turbo (توفير المعالج)</span>
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-400 flex items-center gap-1.5 pt-0.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>الوقت المتبقي التقديري: </span>
                <strong className="text-slate-200">
                  {isCompleted ? '0 ثانية' : formatDuration(speedStats.estimatedSecondsRemaining)}
                </strong>
              </p>
            </div>
          </div>

          {/* Overall Transferred Summary */}
          <div className="w-full md:w-auto flex md:flex-col items-center md:items-end justify-between gap-3 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
            <div className="text-right">
              <span className="text-xs text-slate-400">إجمالي المنقول</span>
              <p className="text-lg font-bold font-mono text-slate-100 tabular-nums">
                {formatFileSize(speedStats.totalTransferredBytes)} <span className="text-slate-500 text-sm font-normal">من</span> {formatFileSize(speedStats.totalBytes)}
              </p>
            </div>

            {/* Smart Compression Savings Tag */}
            {speedStats.compressionSavedBytes > 0 && (
              <div className="text-right bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-xl">
                <span className="text-[10px] text-emerald-400 block font-medium">وفّر الضغط الذكي:</span>
                <span className="text-xs font-bold text-emerald-300 font-mono">
                  +{formatFileSize(speedStats.compressionSavedBytes)} أقل في النقل
                </span>
              </div>
            )}

            <div className="text-left md:text-right">
              <span className="text-xs text-slate-400">الملفات المنجزة</span>
              <p className="text-sm font-semibold text-emerald-400">
                {completedCount} من {files.length} ملف
              </p>
            </div>
          </div>
        </div>

        {/* Master Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs font-semibold">
            <span className="text-slate-300">
              {isCompleted ? 'اكتمل النقل بنجاح! 🚀' : 'جاري النقل بتجزئة ديناميكية ذكية ومراقبة الضغط...'}
            </span>
            <span className="text-emerald-400 font-mono text-sm tabular-nums">
              {speedStats.overallProgress.toFixed(1)}%
            </span>
          </div>

          <div className="h-3.5 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 rounded-full transition-all duration-300 shadow-md shadow-emerald-500/30"
              style={{ width: `${speedStats.overallProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Completion Banner with Actions */}
      {isCompleted && (
        <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 animate-in zoom-in-95 duration-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">تم نقل جميع الملفات بنجاح!</h4>
              <p className="text-xs text-slate-300">
                {role === 'receiver' 
                  ? 'تم استلام وتجميع الملفات بأعلى جودة وبدون انقطاع، يمكنك حفظها لجهازك الآن.' 
                  : 'تم إرسال كافة الملفات إلى الجوال المستلم بنجاح.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {role === 'receiver' && (
              <button
                onClick={handleDownloadAll}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تحميل كافة الملفات</span>
              </button>
            )}

            <button
              onClick={onReset}
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs border border-white/5 transition-colors"
            >
              نقل جديد
            </button>
          </div>
        </div>
      )}

      {/* File Breakdown List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <h4 className="font-bold text-white flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span>تفاصيل الملفات المنقولة ({files.length})</span>
          </h4>
          {!isCompleted && (
            <button
              onClick={onCancel}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 hover:underline"
            >
              <XOctagon className="w-3.5 h-3.5" />
              <span>إلغاء النقل</span>
            </button>
          )}
        </div>

        <div className="space-y-2.5">
          {files.map((file) => {
            const cat = getFileCategory(file.name, file.type);
            const isDone = file.status === 'completed';
            const isTransferring = file.status === 'transferring';

            return (
              <div
                key={file.id}
                className={`p-4 rounded-2xl border transition-all ${
                  isDone
                    ? 'bg-slate-900/40 border-emerald-500/20'
                    : isTransferring
                    ? 'bg-slate-900/80 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
                    : 'bg-slate-900/30 border-white/5 opacity-75'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center shrink-0">
                      {getIconForCategory(cat)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-slate-100 truncate" title={file.name}>
                          {file.name}
                        </p>
                        {file.isCompressed && (
                          <span className="text-[10px] bg-emerald-500/15 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/20 font-medium">
                            مضغوط ذكياً
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                        <span>{formatFileSize(file.size)}</span>
                        <span>·</span>
                        {isDone ? (
                          <span className="text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>مكتمل</span>
                          </span>
                        ) : isTransferring ? (
                          <span className="text-cyan-400 font-mono tabular-nums">
                            {formatFileSize(file.receivedBytes)} ({file.progress}%)
                          </span>
                        ) : (
                          <span className="text-slate-500">قيد الانتظار</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right Action: Download button for receiver */}
                  {role === 'receiver' && isDone && file.blobUrl && (
                    <button
                      onClick={() => handleDownloadFile(file)}
                      className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all active:scale-95"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>حفظ</span>
                    </button>
                  )}
                </div>

                {/* Individual File Progress Bar */}
                <div className="mt-3">
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-200 ${
                        isDone
                          ? 'bg-emerald-400'
                          : isTransferring
                          ? 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                          : 'bg-transparent'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
