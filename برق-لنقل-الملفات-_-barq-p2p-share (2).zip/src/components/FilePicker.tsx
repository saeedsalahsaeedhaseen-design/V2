import React, { useRef, useState } from 'react';
import { 
  UploadCloud, 
  File as FileIcon, 
  X, 
  Film, 
  Image as ImageIcon, 
  Package, 
  FileArchive, 
  FileText, 
  Plus, 
  Sparkles,
  Trash2 
} from 'lucide-react';
import { formatFileSize, getFileCategory, FileCategory } from '../utils/formatters';

interface FilePickerProps {
  files: File[];
  onFilesChange: (files: File[]) => void;
  disabled?: boolean;
}

export const FilePicker: React.FC<FilePickerProps> = ({ files, onFilesChange, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'all' | FileCategory>('all');
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selected = Array.from(e.target.files);
      // Merge unique by name and size
      const existingKeys = new Set(files.map((f) => `${f.name}-${f.size}`));
      const newFiles = selected.filter((f) => !existingKeys.has(`${f.name}-${f.size}`));
      onFilesChange([...files, ...newFiles]);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const dropped = Array.from(e.dataTransfer.files);
      const existingKeys = new Set(files.map((f) => `${f.name}-${f.size}`));
      const newFiles = dropped.filter((f) => !existingKeys.has(`${f.name}-${f.size}`));
      onFilesChange([...files, ...newFiles]);
    }
  };

  const removeFile = (indexToRemove: number) => {
    onFilesChange(files.filter((_, idx) => idx !== indexToRemove));
  };

  const clearAll = () => {
    onFilesChange([]);
  };

  // Helper to create synthetic demo files for rapid testing (e.g., 25MB APK, 60MB Video)
  const addSampleDemoFiles = () => {
    const createDummy = (name: string, type: string, sizeInMB: number): File => {
      // Create empty chunk array to represent size
      const buffer = new Uint8Array(1024 * 64); // 64kb dummy repeating
      const parts: BlobPart[] = [];
      const totalParts = Math.round((sizeInMB * 1024 * 1024) / buffer.byteLength);
      for (let i = 0; i < totalParts; i++) {
        parts.push(buffer);
      }
      const blob = new Blob(parts, { type });
      return new File([blob], name, { type, lastModified: Date.now() });
    };

    const sampleApk = createDummy('CyberSpeed_Racing_v2.4.apk', 'application/vnd.android.package-archive', 35);
    const sampleVideo = createDummy('4K_Nature_Drone_Clip.mp4', 'video/mp4', 65);
    const sampleArchive = createDummy('Game_Assets_Pack_HighRes.zip', 'application/zip', 20);

    onFilesChange([...files, sampleApk, sampleVideo, sampleArchive]);
  };

  const totalSize = files.reduce((acc, f) => acc + f.size, 0);

  const getIconForCategory = (cat: FileCategory) => {
    switch (cat) {
      case 'apk': return <Package className="w-5 h-5 text-emerald-400" />;
      case 'video': return <Film className="w-5 h-5 text-sky-400" />;
      case 'image': return <ImageIcon className="w-5 h-5 text-amber-400" />;
      case 'archive': return <FileArchive className="w-5 h-5 text-purple-400" />;
      case 'document': return <FileText className="w-5 h-5 text-rose-400" />;
      default: return <FileIcon className="w-5 h-5 text-slate-400" />;
    }
  };

  const filteredFiles = files.filter((file) => {
    if (activeTab === 'all') return true;
    return getFileCategory(file.name, file.type) === activeTab;
  });

  return (
    <div className="space-y-4">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled}
      />

      {/* Drop / Tap Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !disabled && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl sm:rounded-3xl p-6 sm:p-8 text-center cursor-pointer transition-all ${
          isDragging
            ? 'border-emerald-400 bg-emerald-500/10 scale-[1.01]'
            : 'border-white/12 bg-slate-900/40 hover:bg-slate-900/70 hover:border-emerald-500/40'
        } ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
      >
        <div className="flex flex-col items-center justify-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/10">
            <UploadCloud className="w-7 h-7" />
          </div>

          <div className="space-y-1">
            <h4 className="text-base sm:text-lg font-bold text-white">
              اضغط لاختيار الملفات أو اسحبها هنا
            </h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              يدعم ألعاب وتطبيقات <span className="text-emerald-400 font-medium">APK</span>، وفيديوهات 4K، والصور، والمجلدات المضغوطة بأي حجم
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <span className="px-3 py-1 rounded-full bg-slate-800/80 border border-white/5 text-[11px] text-slate-300">
              ⚡ نقل مباشر P2P
            </span>
            <span className="px-3 py-1 rounded-full bg-slate-800/80 border border-white/5 text-[11px] text-slate-300">
              🚀 تجزئة سريعة Chunking
            </span>
            <span className="px-3 py-1 rounded-full bg-slate-800/80 border border-white/5 text-[11px] text-slate-300">
              🔒 بدون رفع لسيرفر
            </span>
          </div>
        </div>
      </div>

      {/* Quick Action bar: Add Samples or Clear */}
      <div className="flex items-center justify-between gap-3 text-xs">
        <button
          type="button"
          onClick={addSampleDemoFiles}
          disabled={disabled}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/25 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>إضافة عينة ملفات ضخمة (35MB APK + 65MB فيديو)</span>
        </button>

        {files.length > 0 && (
          <button
            type="button"
            onClick={clearAll}
            disabled={disabled}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>تفريغ القائمة</span>
          </button>
        )}
      </div>

      {/* File List Section */}
      {files.length > 0 && (
        <div className="space-y-3 pt-2">
          {/* Header & Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-white/5">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">الملفات المحددة ({files.length})</span>
              <span className="text-xs text-slate-400">· الإجمالي: {formatFileSize(totalSize)}</span>
            </div>

            {/* Category tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                  activeTab === 'all'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                الكل ({files.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('apk')}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                  activeTab === 'apk'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                APK
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('video')}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                  activeTab === 'video'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                فيديو
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('image')}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                  activeTab === 'image'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                صور
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('archive')}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                  activeTab === 'archive'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                مضغوطة
              </button>
            </div>
          </div>

          {/* Files container */}
          <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
            {filteredFiles.map((file, idx) => {
              const cat = getFileCategory(file.name, file.type);
              const originalIndex = files.indexOf(file);
              return (
                <div
                  key={`${file.name}-${file.size}-${idx}`}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5 hover:border-white/10 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center shrink-0">
                      {getIconForCategory(cat)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm font-medium text-slate-100 truncate" title={file.name}>
                        {file.name}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {formatFileSize(file.size)}
                      </p>
                    </div>
                  </div>

                  {!disabled && (
                    <button
                      type="button"
                      onClick={() => removeFile(originalIndex)}
                      className="w-8 h-8 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 flex items-center justify-center transition-colors shrink-0"
                      title="حذف الملف"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
