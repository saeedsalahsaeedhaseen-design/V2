import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Download, 
  Wifi, 
  QrCode, 
  ArrowRight, 
  Shield, 
  Smartphone, 
  Check, 
  AlertCircle,
  FileText,
  Zap,
  Camera,
  RefreshCw,
  FolderDown
} from 'lucide-react';
import { Header } from './components/Header';
import { HotspotNotice } from './components/HotspotNotice';
import { HotspotGuideModal } from './components/HotspotGuideModal';
import { FilePicker } from './components/FilePicker';
import { QrCodeCard } from './components/QrCodeCard';
import { QrScannerModal } from './components/QrScannerModal';
import { TransferProgressView } from './components/TransferProgressView';
import { SimulatorModal } from './components/SimulatorModal';
import { PeerTransferService } from './services/peerService';
import { TransferFile, SpeedStats, TransferRole, NetworkTier } from './types/transfer';
import { formatFileSize } from './utils/formatters';
import { STANDALONE_INDEX_HTML } from './utils/standaloneHtml';

export default function App() {
  const [role, setRole] = useState<TransferRole>('idle');
  const [shortCode, setShortCode] = useState<string>('');
  const [fullPeerId, setFullPeerId] = useState<string>('');
  const [manualCodeInput, setManualCodeInput] = useState<string>('');
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isTransferring, setIsTransferring] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [filesToTransfer, setFilesToTransfer] = useState<File[]>([]);
  const [activeTransferFiles, setActiveTransferFiles] = useState<TransferFile[]>([]);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Modals state
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState<boolean>(false);
  const [networkTier, setNetworkTier] = useState<NetworkTier>('auto');
  const [turboMode, setTurboMode] = useState<boolean>(true);

  const handleDownloadStandaloneHtml = () => {
    try {
      const blob = new Blob([STANDALONE_INDEX_HTML], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'index.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadNotice(true);
      setTimeout(() => setDownloadNotice(false), 5000);
    } catch (err) {
      setErrorMessage('تعذر تنزيل الملف تلقائياً. تأكد من إعدادات التنزيل في المتصفح.');
    }
  };

  // Speed and progress metrics
  const [speedStats, setSpeedStats] = useState<SpeedStats>({
    bytesPerSecond: 0,
    formattedSpeed: '0 م.ب/ث',
    estimatedSecondsRemaining: 0,
    totalTransferredBytes: 0,
    totalBytes: 0,
    overallProgress: 0,
    networkTierLabel: '5GHz / 4G (كشف تلقائي)',
    activeChunkSizeKB: 256,
    turboActive: true,
    compressionSavedBytes: 0,
  });

  const peerServiceRef = useRef<PeerTransferService | null>(null);
  const simulatorTimerRef = useRef<number | null>(null);

  // Auto-connect if URL contains "?connect=XXXXXX"
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const connectParam = params.get('connect');
    if (connectParam) {
      setRole('receiver');
      setManualCodeInput(connectParam);
      // Initiate receiver connection
      initializeReceiverPeer(connectParam);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      peerServiceRef.current?.destroy();
      if (simulatorTimerRef.current) clearInterval(simulatorTimerRef.current);
    };
  }, []);

  const createPeerService = () => {
    peerServiceRef.current?.destroy();

    const service = new PeerTransferService({
      onOpen: (id, code) => {
        setFullPeerId(id);
        setShortCode(code);
        setStatusMessage('رمز الاتصال جاهز. بانتظار مسح الرمز من الجوال الآخر.');
      },
      onConnected: () => {
        setIsConnected(true);
        setStatusMessage('تم الاتصال بالجوال الآخر بنجاح! ⚡');
        setErrorMessage(null);
      },
      onDisconnected: () => {
        setIsConnected(false);
        setStatusMessage('انقطع الاتصال بالجوال الآخر.');
      },
      onError: (err) => {
        setErrorMessage(err);
      },
      onManifestReceived: (files) => {
        setActiveTransferFiles(files);
        setIsTransferring(true);
        setStatusMessage('تم استلام قائمة الملفات، جاري بدء استقبال البيانات...');
      },
      onFileStart: (fileId) => {
        setActiveTransferFiles((prev) =>
          prev.map((f) => (f.id === fileId ? { ...f, status: 'transferring' } : f))
        );
      },
      onFileChunk: (fileId, chunkIndex, totalChunks, chunkSize) => {
        setActiveTransferFiles((prev) =>
          prev.map((f) => {
            if (f.id === fileId) {
              const newReceived = f.receivedBytes + chunkSize;
              return {
                ...f,
                receivedBytes: newReceived,
                progress: Math.min(100, Math.round((newReceived / f.size) * 100)),
              };
            }
            return f;
          })
        );
      },
      onFileComplete: (completedFile) => {
        setActiveTransferFiles((prev) =>
          prev.map((f) => (f.id === completedFile.id ? completedFile : f))
        );
      },
      onAllCompleted: () => {
        setIsTransferring(false);
        setIsCompleted(true);
        setStatusMessage('اكتمل نقل كافة الملفات بنجاح! 🚀');
      },
      onSpeedUpdate: (stats) => {
        setSpeedStats(stats);
      },
      onCancelled: (reason) => {
        setIsTransferring(false);
        setStatusMessage(reason || 'تم إلغاء النقل');
      },
    });

    peerServiceRef.current = service;
    service.setNetworkTier(networkTier);
    service.setTurboMode(turboMode);
    return service;
  };

  const handleStartSender = async () => {
    setRole('sender');
    setErrorMessage(null);
    setStatusMessage('جاري تهيئة قناة الاتصال اللاسلكية P2P...');
    const service = createPeerService();
    try {
      await service.initialize();
    } catch (e) {
      setErrorMessage('تعذر إنشاء معرف الاتصال. تحقق من الشبكة وحاول مجدداً.');
    }
  };

  const initializeReceiverPeer = async (targetCode: string) => {
    setErrorMessage(null);
    setStatusMessage('جاري الاتصال بالجوال المرسل...');
    const service = createPeerService();
    try {
      await service.initialize(targetCode);
      service.connectToPeer(targetCode);
    } catch (e) {
      setErrorMessage('تعذر الاتصال بالمرسل. تأكد من صحة الرمز.');
    }
  };

  const handleStartReceiver = () => {
    setRole('receiver');
    setErrorMessage(null);
    setStatusMessage('اختر مسح رمز QR أو أدخل كود الاتصال السريع.');
  };

  const handleConnectByCode = () => {
    if (!manualCodeInput.trim()) {
      setErrorMessage('يرجى إدخال كود الاتصال السريع');
      return;
    }
    initializeReceiverPeer(manualCodeInput.trim());
  };

  const handleScanSuccess = (code: string) => {
    setManualCodeInput(code);
    initializeReceiverPeer(code);
  };

  const handleStartFileTransfer = async () => {
    if (filesToTransfer.length === 0) {
      setErrorMessage('يرجى اختيار ملف أو أكثر لبدء الإرسال');
      return;
    }
    if (!peerServiceRef.current || !isConnected) {
      setErrorMessage('يرجى انتظار اتصال الجوال المستلم أولاً');
      return;
    }

    setIsTransferring(true);
    setIsCompleted(false);

    // Initial files state
    const initialFiles: TransferFile[] = filesToTransfer.map((file, idx) => ({
      id: `file_${idx}_${Date.now()}`,
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      file,
      receivedBytes: 0,
      progress: 0,
      status: 'pending',
    }));
    setActiveTransferFiles(initialFiles);

    try {
      await peerServiceRef.current.sendFiles(filesToTransfer);
    } catch (err: any) {
      setErrorMessage(err.message || 'حدث خطأ أثناء نقل الملفات');
      setIsTransferring(false);
    }
  };

  const handleCancelTransfer = () => {
    if (simulatorTimerRef.current) {
      clearInterval(simulatorTimerRef.current);
      simulatorTimerRef.current = null;
    }
    peerServiceRef.current?.cancelTransfer();
    setIsTransferring(false);
    setStatusMessage('تم إلغاء عملية النقل');
  };

  const handleReset = () => {
    if (simulatorTimerRef.current) {
      clearInterval(simulatorTimerRef.current);
      simulatorTimerRef.current = null;
    }
    peerServiceRef.current?.destroy();
    peerServiceRef.current = null;
    setRole('idle');
    setShortCode('');
    setFullPeerId('');
    setManualCodeInput('');
    setIsConnected(false);
    setIsTransferring(false);
    setIsCompleted(false);
    setFilesToTransfer([]);
    setActiveTransferFiles([]);
    setStatusMessage(null);
    setErrorMessage(null);
    setSpeedStats({
      bytesPerSecond: 0,
      formattedSpeed: '0 م.ب/ث',
      estimatedSecondsRemaining: 0,
      totalTransferredBytes: 0,
      totalBytes: 0,
      overallProgress: 0,
      networkTierLabel: '5GHz / 4G (كشف تلقائي)',
      activeChunkSizeKB: 256,
      turboActive: turboMode,
      compressionSavedBytes: 0,
    });
  };

  // Run Benchmark / Simulator
  const handleRunSimulation = (
    demoFiles: TransferFile[],
    simTier: NetworkTier,
    simTurbo: boolean
  ) => {
    handleReset();
    setRole('receiver');
    setIsConnected(true);
    setIsTransferring(true);
    setActiveTransferFiles(demoFiles);
    setNetworkTier(simTier);
    setTurboMode(simTurbo);

    const totalBytes = demoFiles.reduce((acc, f) => acc + f.size, 0);
    let transferred = 0;

    let simSpeedBps = 75 * 1024 * 1024; // 75 MB/s for 5GHz
    let tierLabel = 'نقطة اتصال 5GHz فائقة';
    let chunkKb = 256;

    if (simTier === '4g') {
      simSpeedBps = 28 * 1024 * 1024; // 28 MB/s for 4G
      tierLabel = 'نقطة اتصال 4G / واي فاي سريع';
      chunkKb = 128;
    } else if (simTier === '3g') {
      simSpeedBps = 8.5 * 1024 * 1024; // 8.5 MB/s for 3G
      tierLabel = 'نقطة اتصال 3G / شبكة ضعيفة';
      chunkKb = 32;
    }

    const tickMs = simTurbo ? 140 : 80;
    const bytesPerTick = (simSpeedBps * tickMs) / 1000;

    let currentFileIdx = 0;

    simulatorTimerRef.current = window.setInterval(() => {
      transferred += bytesPerTick;
      const overallProg = Math.min(100, (transferred / totalBytes) * 100);

      // Distribute bytes to current file
      const currentFile = demoFiles[currentFileIdx];
      if (currentFile) {
        currentFile.status = 'transferring';
        currentFile.receivedBytes = Math.min(currentFile.size, currentFile.receivedBytes + bytesPerTick);
        currentFile.progress = Math.min(100, Math.round((currentFile.receivedBytes / currentFile.size) * 100));

        if (currentFile.receivedBytes >= currentFile.size) {
          currentFile.status = 'completed';
          currentFile.progress = 100;
          currentFileIdx++;
        }
      }

      // Add slight jitter for realistic MB/s
      const jitterSpeed = Math.max(1024 * 1024, simSpeedBps + (Math.random() * 6 - 3) * 1024 * 1024);
      const mbps = jitterSpeed / (1024 * 1024);
      const savedBytes = Math.round(transferred * 0.22); // Smart compression savings

      setSpeedStats({
        bytesPerSecond: jitterSpeed,
        formattedSpeed: `${mbps.toFixed(1)} م.ب/ث`,
        estimatedSecondsRemaining: Math.max(0, (totalBytes - transferred) / simSpeedBps),
        totalTransferredBytes: Math.min(totalBytes, transferred),
        totalBytes,
        overallProgress: overallProg,
        networkTierLabel: tierLabel,
        activeChunkSizeKB: chunkKb,
        turboActive: simTurbo,
        compressionSavedBytes: savedBytes,
      });

      setActiveTransferFiles([...demoFiles]);

      if (transferred >= totalBytes || currentFileIdx >= demoFiles.length) {
        if (simulatorTimerRef.current) clearInterval(simulatorTimerRef.current);
        setIsTransferring(false);
        setIsCompleted(true);
        setStatusMessage('اكتمل اختبار السرعة والمحاكاة بنجاح! 🚀');
      }
    }, tickMs);
  };

  const totalSelectedSize = filesToTransfer.reduce((acc, f) => acc + f.size, 0);

  return (
    <div className="min-h-screen bg-[#070B13] text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract */}
      <Header
        onOpenHotspotGuide={() => setIsGuideOpen(true)}
        onOpenSimulator={() => setIsSimulatorOpen(true)}
        onDownloadHtml={handleDownloadStandaloneHtml}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Download Success Notice */}
        {downloadNotice && (
          <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-200 text-xs flex items-center justify-between gap-3 animate-in fade-in duration-200 shadow-lg shadow-emerald-500/10">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>تم تنزيل ملف <strong className="font-mono text-emerald-300">index.html</strong> المستقل بنجاح! يمكنك فتحه مباشرة على أي جوال أو متصفح بدون إنترنت.</span>
            </div>
            <button
              onClick={() => setDownloadNotice(false)}
              className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1"
            >
              حسناً
            </button>
          </div>
        )}

        {/* Upgraded Hotspot Notice with 5GHz, 4G, 3G and Turbo Mode */}
        <HotspotNotice 
          onLearnMore={() => setIsGuideOpen(true)}
          networkTier={networkTier}
          onNetworkTierChange={(t) => {
            setNetworkTier(t);
            peerServiceRef.current?.setNetworkTier(t);
          }}
          turboMode={turboMode}
          onTurboModeToggle={(tb) => {
            setTurboMode(tb);
            peerServiceRef.current?.setTurboMode(tb);
          }}
        />

        {/* Global Error Banner if any */}
        {errorMessage && (
          <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-200 text-xs flex items-center justify-between gap-3 animate-in fade-in duration-200">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-slate-400 hover:text-white text-xs font-semibold"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* ========================================================= */}
        {/* VIEW 1: ACTIVE LIVE TRANSFER SCREEN (Requirement 5)      */}
        {/* ========================================================= */}
        {(isTransferring || isCompleted) && activeTransferFiles.length > 0 ? (
          <TransferProgressView
            role={role}
            files={activeTransferFiles}
            speedStats={speedStats}
            isCompleted={isCompleted}
            onCancel={handleCancelTransfer}
            onReset={handleReset}
          />
        ) : role === 'idle' ? (
          /* ========================================================= */
          /* VIEW 2: HOME SCREEN - DUAL CHOICE (Requirements 1 & 2)    */
          /* ========================================================= */
          <div className="space-y-6">
            {/* Hero Title */}
            <div className="text-center space-y-2 py-4">
              <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
                نقل مباشر وفائق السرعة بين الجوالات
              </h1>
              <p className="text-sm text-slate-400 max-w-lg mx-auto leading-relaxed">
                انقل الفيديوهات الضخمة، وألعاب وتطبيقات <span className="text-emerald-400 font-semibold">APK</span>، والصور بأقصى سرعة اتصال محلي P2P وبدون أي حدود للحجم.
              </p>
            </div>

            {/* Dual Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
              {/* Option 1: Send Files */}
              <div 
                onClick={handleStartSender}
                className="group relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-white/10 hover:border-emerald-500/50 p-6 sm:p-8 transition-all hover:shadow-2xl hover:shadow-emerald-500/10 active:scale-[0.99] flex flex-col justify-between space-y-6"
              >
                <div className="space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform shadow-lg shadow-emerald-500/10">
                    <Send className="w-7 h-7 -translate-x-0.5" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl sm:text-2xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                        إرسال ملفات
                      </h3>
                      <span className="text-xs bg-emerald-500/20 text-emerald-400 font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">
                        المرسل
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                      اختر ملفاتك بأي حجم، وسيقوم التطبيق بتوليد كود اتصال فوري ورمز QR Code ليقوم الجوال المستلم بمسحه وبدء النقل مباشرة.
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  <span className="text-xs text-emerald-400 font-semibold group-hover:underline">
                    بدء الإرسال وتوليد الرمز
                  </span>
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-all">
                    <ArrowRight className="w-4 h-4 rotate-180" />
                  </div>
                </div>
              </div>

              {/* Option 2: Receive Files */}
              <div 
                onClick={handleStartReceiver}
                className="group relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-white/10 hover:border-cyan-500/50 p-6 sm:p-8 transition-all hover:shadow-2xl hover:shadow-cyan-500/10 active:scale-[0.99] flex flex-col justify-between space-y-6"
              >
                <div className="space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform shadow-lg shadow-cyan-500/10">
                    <Download className="w-7 h-7" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl sm:text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                        استلام ملفات
                      </h3>
                      <span className="text-xs bg-cyan-500/20 text-cyan-400 font-mono px-2 py-0.5 rounded-full border border-cyan-500/30">
                        المستلم
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                      امسح رمز QR الخاص بالجوال المرسل عبر الكاميرا أو أدخل الكود القصير للاتصال الفوري وتنزيل الملفات لجهازك.
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  <span className="text-xs text-cyan-400 font-semibold group-hover:underline">
                    مسح الكود أو الإدخال اليدوي
                  </span>
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all">
                    <ArrowRight className="w-4 h-4 rotate-180" />
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Feature Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">سرعة 5GHz المحلية</h4>
                  <p className="text-[11px] text-slate-400">تصل إلى 80MB/s بدون إنترنت</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">تشفير تام P2P</h4>
                  <p className="text-[11px] text-slate-400">من جهاز لجهاز بدون وسيط</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">متوافق مع أندرويد وآيفون</h4>
                  <p className="text-[11px] text-slate-400">يعمل مباشرة من المتصفح</p>
                </div>
              </div>
            </div>
          </div>
        ) : role === 'sender' ? (
          /* ========================================================= */
          /* VIEW 3: SENDER MODE (Requirement 3)                       */
          /* ========================================================= */
          <div className="space-y-6">
            {/* Header back button */}
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleReset}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
                <h2 className="text-lg font-bold text-white">إرسال ملفات (الجوال المرسل)</h2>
              </div>

              <button
                onClick={handleReset}
                className="text-xs text-slate-400 hover:text-white"
              >
                رجوع للرئيسية
              </button>
            </div>

            {/* Step 1: Pairing QR Code & Short PIN */}
            <QrCodeCard
              shortCode={shortCode}
              isConnected={isConnected}
              onRefreshCode={handleStartSender}
            />

            {/* Step 2: Multi-file picker */}
            <div className="space-y-3 pt-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>اختر الملفات المراد إرسالها</span>
              </h3>
              
              <FilePicker
                files={filesToTransfer}
                onFilesChange={setFilesToTransfer}
                disabled={isTransferring}
              />
            </div>

            {/* Send CTA Button */}
            <div className="pt-4">
              <button
                type="button"
                onClick={handleStartFileTransfer}
                disabled={filesToTransfer.length === 0 || !isConnected || isTransferring}
                className={`w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-3 transition-all ${
                  filesToTransfer.length > 0 && isConnected && !isTransferring
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-xl shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99]'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                }`}
              >
                <Send className="w-5 h-5 -translate-x-0.5" />
                {filesToTransfer.length === 0 ? (
                  <span>اختر الملفات أولاً لبدء النقل</span>
                ) : !isConnected ? (
                  <span>في انتظار مسح الرمز من الجوال المستلم للبدء...</span>
                ) : (
                  <span>بدء نقل {filesToTransfer.length} ملفات ({formatFileSize(totalSelectedSize)}) ⚡</span>
                )}
              </button>
            </div>
          </div>
        ) : (
          /* ========================================================= */
          /* VIEW 4: RECEIVER MODE (Requirement 4)                     */
          /* ========================================================= */
          <div className="space-y-6">
            {/* Header back button */}
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleReset}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
                <h2 className="text-lg font-bold text-white">استلام ملفات (الجوال المستلم)</h2>
              </div>

              <button
                onClick={handleReset}
                className="text-xs text-slate-400 hover:text-white"
              >
                رجوع للرئيسية
              </button>
            </div>

            {/* Receiver Pairing Box */}
            <div className="rounded-3xl bg-slate-900/50 border border-white/10 p-6 sm:p-8 space-y-6">
              {/* Option A: Scan QR Code with Camera */}
              <div className="text-center space-y-4">
                <button
                  onClick={() => setIsScannerOpen(true)}
                  className="w-full sm:w-auto mx-auto py-4 px-8 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold text-base flex items-center justify-center gap-3 shadow-xl shadow-emerald-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  <Camera className="w-6 h-6" />
                  <span>مسح رمز QR من الجوال المرسل</span>
                </button>

                <p className="text-xs text-slate-400">
                  سيفتح الكاميرا لمسح الرمز المعروض على شاشة الجوال الآخر للربط التلقائي
                </p>
              </div>

              {/* Divider */}
              <div className="relative flex items-center justify-center">
                <div className="border-t border-white/10 w-full" />
                <span className="bg-[#0C121F] px-4 text-xs text-slate-400 font-medium">أو إدخال الكود يدوياً</span>
              </div>

              {/* Option B: Manual Short PIN input */}
              <div className="max-w-md mx-auto space-y-3">
                <label className="text-xs font-semibold text-slate-300 block text-right">
                  كود الاتصال السريع (6 أرقام):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={manualCodeInput}
                    onChange={(e) => setManualCodeInput(e.target.value)}
                    placeholder="مثال: 942-815"
                    className="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-white/10 text-white font-mono text-center text-lg sm:text-xl tracking-widest focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    onClick={handleConnectByCode}
                    className="py-3 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm transition-colors border border-white/10 shrink-0"
                  >
                    اتصال فوري
                  </button>
                </div>
              </div>

              {/* Connection Status Indicator */}
              <div className={`p-4 rounded-xl border flex items-center justify-center gap-2.5 text-xs font-medium ${
                isConnected
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                  : 'bg-slate-950/60 border-white/5 text-slate-400'
              }`}>
                {isConnected ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>متصل الآن بالجوال المرسل! بانتظار بدء إرسال الملفات...</span>
                  </>
                ) : (
                  <>
                    <Wifi className="w-4 h-4 text-slate-500" />
                    <span>بانتظار مسح الرمز أو إدخال الكود للربط المباشر...</span>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-white/5 py-4 px-6 text-center text-xs text-slate-500">
        <p>برق P2P · نقل الملفات المباشر عبر WebRTC ونقطة اتصال 5GHz · محلي وآمن 100%</p>
      </footer>

      {/* Modals */}
      <HotspotGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />

      <QrScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanSuccess={handleScanSuccess}
      />

      <SimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onRunSimulation={handleRunSimulation}
      />
    </div>
  );
}
