import Peer, { DataConnection } from 'peerjs';
import { TransferFile, TransferPacket, SpeedStats, NetworkTier, TurboSettings } from '../types/transfer';
import { getActiveProfile, detectNetworkCondition } from '../utils/networkProfiler';
import { isFileCompressible, canCompressChunk, decompressBuffer } from '../utils/compression';

export interface PeerCallbacks {
  onOpen: (peerId: string, shortCode: string) => void;
  onConnected: (peerId: string) => void;
  onDisconnected: () => void;
  onError: (error: string) => void;
  onManifestReceived: (files: TransferFile[]) => void;
  onFileStart: (fileId: string) => void;
  onFileChunk: (fileId: string, chunkIndex: number, totalChunks: number, chunkSize: number) => void;
  onFileComplete: (file: TransferFile) => void;
  onAllCompleted: () => void;
  onSpeedUpdate: (stats: SpeedStats) => void;
  onCancelled: (reason?: string) => void;
  onNetworkTierChange?: (tierLabel: string, detected: string, chunkSizeKB: number) => void;
}

export class PeerTransferService {
  private peer: Peer | null = null;
  private connection: DataConnection | null = null;
  private callbacks: PeerCallbacks;
  private isDestroyed = false;
  private role: 'sender' | 'receiver' | 'idle' = 'idle';

  // Network and Turbo Settings
  private networkTier: NetworkTier = 'auto';
  private turboSettings: TurboSettings = {
    enabled: false,
    uiThrottleMs: 250,
    memoryBatchMb: 16,
    disableAnimations: true,
  };
  private measuredRtt: number = 0;
  private lastPingSentTime: number = 0;
  private pingIntervalTimer: number | null = null;

  // State for files and stats
  private files: TransferFile[] = [];
  private currentFileIndex = 0;
  private totalBytesToTransfer = 0;
  private totalBytesTransferred = 0;
  private compressionSavedBytes = 0;
  private isTransferring = false;
  private isCancelled = false;

  // Receiver chunk memory segments (used in Turbo Mode to prevent memory bloat on weak phones)
  private receiverBlobSegments: Map<string, Blob[]> = new Map();
  private receiverSegmentBuffer: Map<string, ArrayBuffer[]> = new Map();

  // Speed calculation
  private speedWindow: { time: number; bytes: number }[] = [];
  private speedIntervalTimer: number | null = null;
  private lastUiEmitTime: number = 0;

  constructor(callbacks: PeerCallbacks) {
    this.callbacks = callbacks;
  }

  public setNetworkTier(tier: NetworkTier): void {
    this.networkTier = tier;
    const profile = getActiveProfile(tier, this.measuredRtt);
    this.callbacks.onNetworkTierChange?.(profile.label, profile.detectedTier, Math.round(profile.chunkSize / 1024));
  }

  public setTurboMode(enabled: boolean): void {
    this.turboSettings.enabled = enabled;
  }

  public getShortCode(fullPeerId: string): string {
    if (fullPeerId.startsWith('barq-')) {
      const code = fullPeerId.replace('barq-', '');
      if (code.length === 6) {
        return `${code.slice(0, 3)}-${code.slice(3)}`;
      }
      return code;
    }
    return fullPeerId.slice(-6);
  }

  public static parseCodeToPeerId(code: string): string {
    const clean = code.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    if (clean.startsWith('barq')) {
      return clean;
    }
    return `barq-${clean}`;
  }

  public initialize(targetCode?: string): Promise<string> {
    return new Promise((resolve, reject) => {
      try {
        const randomDigits = Math.floor(100000 + Math.random() * 900000).toString();
        const peerId = targetCode ? undefined : `barq-${randomDigits}`;

        this.peer = new Peer(peerId as any, {
          debug: 1,
          config: {
            iceServers: [
              { urls: 'stun:stun.l.google.com:19302' },
              { urls: 'stun:stun1.l.google.com:19302' },
              { urls: 'stun:stun2.l.google.com:19302' },
            ],
          },
        });

        this.peer.on('open', (id) => {
          if (this.isDestroyed) return;
          const shortCode = this.getShortCode(id);
          this.callbacks.onOpen(id, shortCode);
          resolve(id);
        });

        this.peer.on('connection', (conn) => {
          this.handleIncomingConnection(conn);
        });

        this.peer.on('error', (err) => {
          console.error('[PeerJS Error]', err);
          let message = 'حدث خطأ في الاتصال بالشبكة';
          if (err.type === 'peer-unavailable') {
            message = 'لم يتم العثور على الجوال الآخر، تأكد من صحة الرمز وتواجد الجهازين على نفس نقطة الاتصال (5GHz / 4G / 3G).';
          } else if (err.type === 'network') {
            message = 'تعذر الاتصال بخادم التنسيق. تأكد من تفعيل الاتصال بنقطة الاتصال أو الواي فاي.';
          } else if (err.type === 'unavailable-id') {
            message = 'رمز الاتصال مستخدم حالياً، جاري توليد رمز جديد...';
          }
          this.callbacks.onError(message);
        });

        this.peer.on('disconnected', () => {
          if (!this.isDestroyed) {
            try {
              this.peer?.reconnect();
            } catch (e) {
              console.warn('Reconnect error', e);
            }
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  public connectToPeer(remoteShortOrFullCode: string): void {
    if (!this.peer) {
      this.callbacks.onError('خدمة الاتصال غير مهيأة بعد');
      return;
    }

    const remotePeerId = PeerTransferService.parseCodeToPeerId(remoteShortOrFullCode);
    this.role = 'receiver';

    const conn = this.peer.connect(remotePeerId, {
      reliable: true,
      serialization: 'binary',
    });

    this.setupConnectionEvents(conn);
  }

  private handleIncomingConnection(conn: DataConnection): void {
    this.role = 'sender';
    this.setupConnectionEvents(conn);
  }

  private setupConnectionEvents(conn: DataConnection): void {
    this.connection = conn;

    conn.on('open', () => {
      this.callbacks.onConnected(conn.peer);
      this.startSpeedTracker();
      this.startPingMeasurement();
    });

    conn.on('data', (raw: unknown) => {
      this.handleIncomingData(raw as TransferPacket);
    });

    conn.on('close', () => {
      this.stopSpeedTracker();
      this.stopPingMeasurement();
      this.callbacks.onDisconnected();
    });

    conn.on('error', (err) => {
      console.error('[Connection Error]', err);
      this.callbacks.onError('حدث انقطاع في قناة النقل المباشر');
    });
  }

  private startPingMeasurement(): void {
    this.stopPingMeasurement();
    this.sendPing();
    this.pingIntervalTimer = window.setInterval(() => {
      if (this.connection && this.connection.open) {
        this.sendPing();
      }
    }, 4000);
  }

  private stopPingMeasurement(): void {
    if (this.pingIntervalTimer) {
      clearInterval(this.pingIntervalTimer);
      this.pingIntervalTimer = null;
    }
  }

  private sendPing(): void {
    this.lastPingSentTime = Date.now();
    try {
      this.connection?.send({
        type: 'PING',
        timestamp: this.lastPingSentTime,
      });
    } catch (e) {}
  }

  private async handleIncomingData(packet: TransferPacket): Promise<void> {
    if (!packet || typeof packet !== 'object') return;

    switch (packet.type) {
      case 'PING': {
        try {
          this.connection?.send({
            type: 'PONG',
            timestamp: packet.timestamp,
          });
        } catch (e) {}
        break;
      }

      case 'PONG': {
        const rtt = Math.max(1, Date.now() - packet.timestamp);
        this.measuredRtt = rtt;
        const profile = getActiveProfile(this.networkTier, this.measuredRtt);
        this.callbacks.onNetworkTierChange?.(profile.label, profile.detectedTier, Math.round(profile.chunkSize / 1024));
        break;
      }

      case 'MANIFEST': {
        this.files = packet.files.map((f) => ({
          ...f,
          receivedChunks: [],
          receivedBytes: 0,
          progress: 0,
          status: 'pending',
        }));
        this.totalBytesToTransfer = packet.totalSize;
        this.totalBytesTransferred = 0;
        this.compressionSavedBytes = 0;

        // Reset memory segments for Turbo Mode
        this.receiverBlobSegments.clear();
        this.receiverSegmentBuffer.clear();

        this.callbacks.onManifestReceived(this.files);
        break;
      }

      case 'FILE_START': {
        const file = this.files.find((f) => f.id === packet.fileId);
        if (file) {
          file.status = 'transferring';
          file.receivedChunks = [];
          file.receivedBytes = 0;
          file.progress = 0;
          file.isCompressed = packet.isCompressed;
          file.originalSize = packet.originalSize || packet.fileSize;

          this.receiverBlobSegments.set(packet.fileId, []);
          this.receiverSegmentBuffer.set(packet.fileId, []);

          this.callbacks.onFileStart(packet.fileId);
        }
        break;
      }

      case 'FILE_CHUNK': {
        const file = this.files.find((f) => f.id === packet.fileId);
        if (file) {
          let chunkData = packet.data;

          // Decompress chunk if it was compressed
          if (packet.isCompressed) {
            try {
              const decompressed = await decompressBuffer(chunkData);
              const savedBytes = decompressed.byteLength - chunkData.byteLength;
              if (savedBytes > 0) {
                this.compressionSavedBytes += savedBytes;
              }
              chunkData = decompressed;
            } catch (e) {
              console.warn('Chunk decompression failed, using raw data', e);
            }
          }

          const chunkSize = chunkData.byteLength;
          file.receivedBytes += chunkSize;
          this.totalBytesTransferred += chunkSize;
          file.progress = Math.min(100, Math.round((file.receivedBytes / file.size) * 100));

          // Turbo Mode Memory Optimization:
          // In Turbo Mode, periodically consolidate chunks into Blobs every 16MB to release raw ArrayBuffer memory
          if (this.turboSettings.enabled) {
            let buffer = this.receiverSegmentBuffer.get(packet.fileId) || [];
            buffer.push(chunkData);

            const bufferTotalBytes = buffer.reduce((acc, b) => acc + b.byteLength, 0);
            if (bufferTotalBytes >= this.turboSettings.memoryBatchMb * 1024 * 1024) {
              const segmentBlob = new Blob(buffer);
              const segments = this.receiverBlobSegments.get(packet.fileId) || [];
              segments.push(segmentBlob);
              this.receiverBlobSegments.set(packet.fileId, segments);
              buffer = [];
              this.receiverSegmentBuffer.set(packet.fileId, buffer);
            }
          } else {
            if (!file.receivedChunks) file.receivedChunks = [];
            file.receivedChunks[packet.chunkIndex] = chunkData;
          }

          this.recordTransferredBytes(chunkSize);

          // In Turbo Mode, throttle UI callbacks to save receiver CPU
          const now = Date.now();
          if (!this.turboSettings.enabled || now - this.lastUiEmitTime >= this.turboSettings.uiThrottleMs) {
            this.lastUiEmitTime = now;
            this.callbacks.onFileChunk(packet.fileId, packet.chunkIndex, packet.totalChunks, chunkSize);
          }
        }
        break;
      }

      case 'FILE_COMPLETE': {
        const file = this.files.find((f) => f.id === packet.fileId);
        if (file) {
          file.status = 'completed';
          file.progress = 100;

          try {
            let finalBlob: Blob;
            if (this.turboSettings.enabled) {
              const buffer = this.receiverSegmentBuffer.get(packet.fileId) || [];
              const segments = this.receiverBlobSegments.get(packet.fileId) || [];
              if (buffer.length > 0) {
                segments.push(new Blob(buffer));
              }
              finalBlob = new Blob(segments, { type: file.type || 'application/octet-stream' });
              // Clear temporary buffers to release memory
              this.receiverBlobSegments.delete(packet.fileId);
              this.receiverSegmentBuffer.delete(packet.fileId);
            } else {
              finalBlob = new Blob(file.receivedChunks || [], { type: file.type || 'application/octet-stream' });
            }

            file.blobUrl = URL.createObjectURL(finalBlob);
          } catch (err) {
            console.error('Error assembling blob on receiver', err);
          }

          this.callbacks.onFileComplete(file);
        }
        break;
      }

      case 'TRANSFER_COMPLETE': {
        this.isTransferring = false;
        this.stopSpeedTracker();
        this.callbacks.onAllCompleted();
        break;
      }

      case 'TRANSFER_CANCEL': {
        this.isTransferring = false;
        this.isCancelled = true;
        this.stopSpeedTracker();
        this.callbacks.onCancelled(packet.reason);
        break;
      }
    }
  }

  public async sendFiles(filesToSend: File[]): Promise<void> {
    if (!this.connection || !this.connection.open) {
      throw new Error('لا يوجد اتصال نشط مع الجوال الآخر');
    }

    this.isTransferring = true;
    this.isCancelled = false;

    // Determine current dynamic network profile
    const profile = getActiveProfile(this.networkTier, this.measuredRtt);
    const activeChunkSize = profile.chunkSize;
    const activeWatermark = profile.bufferWatermark;

    this.files = filesToSend.map((file, idx) => ({
      id: `file_${idx}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      lastModified: file.lastModified,
      file,
      receivedBytes: 0,
      progress: 0,
      status: 'pending',
      isCompressed: isFileCompressible(file.name, file.type),
      originalSize: file.size,
    }));

    this.totalBytesToTransfer = this.files.reduce((acc, f) => acc + f.size, 0);
    this.totalBytesTransferred = 0;
    this.compressionSavedBytes = 0;
    this.currentFileIndex = 0;

    // Send manifest packet with turbo and chunk settings
    const manifestPacket: TransferPacket = {
      type: 'MANIFEST',
      files: this.files.map((f) => ({
        id: f.id,
        name: f.name,
        size: f.size,
        type: f.type,
        isCompressed: f.isCompressed,
        originalSize: f.originalSize,
      })),
      totalSize: this.totalBytesToTransfer,
      turboEnabled: this.turboSettings.enabled,
      chunkSize: activeChunkSize,
    };
    this.connection.send(manifestPacket);

    await new Promise((r) => setTimeout(r, 80));

    for (let i = 0; i < this.files.length; i++) {
      if (this.isCancelled) break;
      this.currentFileIndex = i;
      await this.streamSingleFile(this.files[i], activeChunkSize, activeWatermark);
    }

    if (!this.isCancelled) {
      this.connection.send({ type: 'TRANSFER_COMPLETE' });
      this.isTransferring = false;
      this.stopSpeedTracker();
      this.callbacks.onAllCompleted();
    }
  }

  private async streamSingleFile(transferFile: TransferFile, chunkSize: number, bufferWatermark: number): Promise<void> {
    const file = transferFile.file;
    if (!file) return;

    transferFile.status = 'transferring';
    this.callbacks.onFileStart(transferFile.id);

    const totalChunks = Math.ceil(file.size / chunkSize);
    const shouldTestCompression = isFileCompressible(file.name, file.type);

    this.connection?.send({
      type: 'FILE_START',
      fileId: transferFile.id,
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      totalChunks,
      chunkSize,
      isCompressed: shouldTestCompression,
      originalSize: file.size,
    });

    let offset = 0;
    let chunkIndex = 0;

    while (offset < file.size) {
      if (this.isCancelled) break;

      // Smart dynamic backpressure throttling
      await this.waitForBufferDrain(bufferWatermark);

      const sliceEnd = Math.min(offset + chunkSize, file.size);
      const slice = file.slice(offset, sliceEnd);
      let buffer = await slice.arrayBuffer();
      let chunkIsCompressed = false;

      // Smart on-the-fly chunk compression
      if (shouldTestCompression) {
        const probe = await canCompressChunk(buffer);
        if (probe.shouldCompress && probe.compressed) {
          const savedBytes = buffer.byteLength - probe.compressed.byteLength;
          this.compressionSavedBytes += savedBytes;
          buffer = probe.compressed;
          chunkIsCompressed = true;
        }
      }

      const chunkPacket: TransferPacket = {
        type: 'FILE_CHUNK',
        fileId: transferFile.id,
        chunkIndex,
        totalChunks,
        isCompressed: chunkIsCompressed,
        data: buffer,
      };

      this.connection?.send(chunkPacket);

      const originalChunkBytes = sliceEnd - offset;
      transferFile.receivedBytes += originalChunkBytes;
      this.totalBytesTransferred += originalChunkBytes;
      transferFile.progress = Math.min(100, Math.round((transferFile.receivedBytes / transferFile.size) * 100));

      this.recordTransferredBytes(originalChunkBytes);

      // In Turbo Mode, throttle UI callbacks to save sender CPU
      const now = Date.now();
      if (!this.turboSettings.enabled || now - this.lastUiEmitTime >= this.turboSettings.uiThrottleMs) {
        this.lastUiEmitTime = now;
        this.callbacks.onFileChunk(transferFile.id, chunkIndex, totalChunks, originalChunkBytes);
      }

      offset += chunkSize;
      chunkIndex++;
    }

    if (!this.isCancelled) {
      transferFile.status = 'completed';
      transferFile.progress = 100;
      this.connection?.send({
        type: 'FILE_COMPLETE',
        fileId: transferFile.id,
        isCompressed: shouldTestCompression,
      });
      this.callbacks.onFileComplete(transferFile);
    }
  }

  private async waitForBufferDrain(highWatermark: number): Promise<void> {
    if (!this.connection) return;

    const dc: RTCDataChannel | undefined = (this.connection as any).dataChannel;
    if (!dc) return;

    if (dc.bufferedAmount > highWatermark) {
      await new Promise<void>((resolve) => {
        const check = () => {
          if (!dc || dc.bufferedAmount <= highWatermark / 2) {
            resolve();
          } else {
            setTimeout(check, 10);
          }
        };
        check();
      });
    }
  }

  public cancelTransfer(reason = 'تم إلغاء النقل من قبل المستخدم'): void {
    this.isCancelled = true;
    this.isTransferring = false;
    this.stopSpeedTracker();
    if (this.connection && this.connection.open) {
      try {
        this.connection.send({ type: 'TRANSFER_CANCEL', reason });
      } catch (e) {
        console.warn('Error sending cancel packet', e);
      }
    }
    this.callbacks.onCancelled(reason);
  }

  private startSpeedTracker(): void {
    this.stopSpeedTracker();
    this.speedWindow = [];
    this.speedIntervalTimer = window.setInterval(() => {
      this.computeSpeed();
    }, 350);
  }

  private stopSpeedTracker(): void {
    if (this.speedIntervalTimer !== null) {
      clearInterval(this.speedIntervalTimer);
      this.speedIntervalTimer = null;
    }
  }

  private recordTransferredBytes(bytes: number): void {
    const now = Date.now();
    this.speedWindow.push({ time: now, bytes });

    const cutoff = now - 2000;
    while (this.speedWindow.length > 0 && this.speedWindow[0].time < cutoff) {
      this.speedWindow.shift();
    }
  }

  private computeSpeed(): void {
    const now = Date.now();
    const cutoff = now - 2000;
    while (this.speedWindow.length > 0 && this.speedWindow[0].time < cutoff) {
      this.speedWindow.shift();
    }

    const windowBytes = this.speedWindow.reduce((acc, item) => acc + item.bytes, 0);
    const windowDuration = this.speedWindow.length > 1
      ? (now - this.speedWindow[0].time) / 1000
      : 1;

    const bytesPerSecond = windowDuration > 0 ? windowBytes / windowDuration : 0;
    const mbps = bytesPerSecond / (1024 * 1024);

    const remainingBytes = Math.max(0, this.totalBytesToTransfer - this.totalBytesTransferred);
    const estimatedSecondsRemaining = bytesPerSecond > 0 ? remainingBytes / bytesPerSecond : 0;
    const overallProgress = this.totalBytesToTransfer > 0
      ? Math.min(100, (this.totalBytesTransferred / this.totalBytesToTransfer) * 100)
      : 0;

    let formattedSpeed = '0 م.ب/ث';
    if (mbps >= 1) {
      formattedSpeed = `${mbps.toFixed(1)} م.ب/ث`;
    } else {
      const kbps = bytesPerSecond / 1024;
      formattedSpeed = `${kbps.toFixed(0)} ك.ب/ث`;
    }

    const currentProfile = getActiveProfile(this.networkTier, this.measuredRtt);

    this.callbacks.onSpeedUpdate({
      bytesPerSecond,
      formattedSpeed,
      estimatedSecondsRemaining,
      totalTransferredBytes: this.totalBytesTransferred,
      totalBytes: this.totalBytesToTransfer,
      overallProgress,
      networkTierLabel: currentProfile.label,
      activeChunkSizeKB: Math.round(currentProfile.chunkSize / 1024),
      turboActive: this.turboSettings.enabled,
      compressionSavedBytes: this.compressionSavedBytes,
    });
  }

  public destroy(): void {
    this.isDestroyed = true;
    this.stopSpeedTracker();
    this.stopPingMeasurement();
    if (this.connection) {
      try {
        this.connection.close();
      } catch (e) {
        console.warn('Error closing connection', e);
      }
      this.connection = null;
    }
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch (e) {
        console.warn('Error destroying peer', e);
      }
      this.peer = null;
    }
  }
}
